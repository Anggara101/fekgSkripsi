//
// File: wnoisest.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "wnoisest.h"
#include "FekgClus_emxutil.h"
#include "sort3.h"
#include "quickselect.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *c
//                const double varargin_1[7]
//                double stdc[5]
// Return Type  : void
//
void wnoisest(const emxArray_real_T *c, const double varargin_1[7], double stdc
              [5])
{
  int i;
  int first[5];
  int last[5];
  int j;
  emxArray_real_T *y;
  int unusedU5;
  int vlen;
  double m;
  int exitg1;
  int midm1;
  double b;
  boolean_T p;
  for (i = 0; i < 5; i++) {
    first[i] = 0;
    last[i] = 0;
  }

  first[4] = (int)varargin_1[0] + 1;
  last[4] = (int)varargin_1[0] + (int)varargin_1[1];
  for (j = 3; j >= 0; j--) {
    first[j] = first[j + 1] + (int)varargin_1[4 - j];
    last[j] = (first[j] + (int)varargin_1[5 - j]) - 1;
  }

  emxInit_real_T(&y, 2);
  for (j = 0; j < 5; j++) {
    if (first[j] > last[j]) {
      unusedU5 = 1;
      vlen = 1;
    } else {
      unusedU5 = first[j];
      vlen = last[j] + 1;
    }

    i = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = vlen - unusedU5;
    emxEnsureCapacity_real_T(y, i);
    for (i = -1; i + 2 <= vlen - unusedU5; i++) {
      y->data[i + 1] = std::abs(c->data[unusedU5 + i]);
    }

    vlen = y->size[1];
    if (y->size[1] == 0) {
      m = rtNaN;
    } else {
      i = 1;
      do {
        exitg1 = 0;
        if (i <= vlen) {
          if (rtIsNaN(y->data[i - 1])) {
            m = rtNaN;
            exitg1 = 1;
          } else {
            i++;
          }
        } else {
          if (vlen <= 4) {
            if (vlen == 0) {
              m = rtNaN;
            } else if (vlen == 1) {
              m = y->data[0];
            } else if (vlen == 2) {
              if (rtIsInf(y->data[0]) || rtIsInf(y->data[1])) {
                m = (y->data[0] + y->data[1]) / 2.0;
              } else {
                m = y->data[0] + (y->data[1] - y->data[0]) / 2.0;
              }
            } else if (vlen == 3) {
              p = (y->data[0] < y->data[1]);
              if (p) {
                p = (y->data[1] < y->data[2]);
                if (p) {
                  unusedU5 = 1;
                } else {
                  p = (y->data[0] < y->data[2]);
                  if (p) {
                    unusedU5 = 2;
                  } else {
                    unusedU5 = 0;
                  }
                }
              } else {
                p = (y->data[0] < y->data[2]);
                if (p) {
                  unusedU5 = 0;
                } else {
                  p = (y->data[1] < y->data[2]);
                  if (p) {
                    unusedU5 = 2;
                  } else {
                    unusedU5 = 1;
                  }
                }
              }

              m = y->data[unusedU5];
            } else {
              sort3(1, y->data[0], 2, y->data[1], 3, y->data[2], &i, &unusedU5,
                    &vlen);
              p = (y->data[i - 1] < y->data[3]);
              if (p) {
                p = (y->data[3] < y->data[vlen - 1]);
                if (p) {
                  if (rtIsInf(y->data[unusedU5 - 1]) || rtIsInf(y->data[3])) {
                    m = (y->data[unusedU5 - 1] + y->data[3]) / 2.0;
                  } else {
                    m = y->data[unusedU5 - 1] + (y->data[3] - y->data[unusedU5 -
                      1]) / 2.0;
                  }
                } else if (rtIsInf(y->data[unusedU5 - 1]) || rtIsInf(y->
                            data[vlen - 1])) {
                  m = (y->data[unusedU5 - 1] + y->data[vlen - 1]) / 2.0;
                } else {
                  m = y->data[unusedU5 - 1] + (y->data[vlen - 1] - y->
                    data[unusedU5 - 1]) / 2.0;
                }
              } else if (rtIsInf(y->data[i - 1]) || rtIsInf(y->data[unusedU5 - 1]))
              {
                m = (y->data[i - 1] + y->data[unusedU5 - 1]) / 2.0;
              } else {
                m = y->data[i - 1] + (y->data[unusedU5 - 1] - y->data[i - 1]) /
                  2.0;
              }
            }
          } else {
            midm1 = vlen >> 1;
            if ((vlen & 1) == 0) {
              quickselect(y, midm1 + 1, vlen, &m, &i, &unusedU5);
              if (midm1 < i) {
                quickselect(y, midm1, unusedU5 - 1, &b, &i, &vlen);
                if (rtIsInf(m) || rtIsInf(b)) {
                  m = (m + b) / 2.0;
                } else {
                  m += (b - m) / 2.0;
                }
              }
            } else {
              quickselect(y, midm1 + 1, vlen, &m, &i, &unusedU5);
            }
          }

          exitg1 = 1;
        }
      } while (exitg1 == 0);
    }

    stdc[j] = m / 0.6745;
  }

  emxFree_real_T(&y);
}

//
// File trailer for wnoisest.cpp
//
// [EOF]
//
