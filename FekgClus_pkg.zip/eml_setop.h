//
// File: eml_setop.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//
#ifndef EML_SETOP_H
#define EML_SETOP_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "FekgClus_types.h"

// Function Declarations
extern void do_vectors(const emxArray_int32_T *a, const emxArray_int32_T *b,
  emxArray_int32_T *c, emxArray_int32_T *ia, emxArray_int32_T *ib);

#endif

//
// File trailer for eml_setop.h
//
// [EOF]
//
