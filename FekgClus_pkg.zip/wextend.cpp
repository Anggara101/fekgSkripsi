//
// File: wextend.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "wextend.h"
#include "FekgClus_emxutil.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *x
//                double lf
//                emxArray_real_T *y
// Return Type  : void
//
void wextend(const emxArray_real_T *x, double lf, emxArray_real_T *y)
{
  int ny;
  int i2;
  ny = x->size[1] + (int)lf;
  i2 = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = ny;
  emxEnsureCapacity_real_T(y, i2);
  for (i2 = 0; i2 < ny; i2++) {
    y->data[i2] = 0.0;
  }

  for (ny = 0; ny + 1 <= x->size[1]; ny++) {
    y->data[y->size[0] * ny] = x->data[x->size[0] * ny];
  }
}

//
// File trailer for wextend.cpp
//
// [EOF]
//
