//
// File: dwt.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//
#ifndef DWT_H
#define DWT_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "FekgClus_types.h"

// Function Declarations
extern void dwt(const emxArray_real_T *x, emxArray_real_T *a, emxArray_real_T *d);

#endif

//
// File trailer for dwt.h
//
// [EOF]
//
