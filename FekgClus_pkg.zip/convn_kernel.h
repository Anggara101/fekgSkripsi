//
// File: convn_kernel.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//
#ifndef CONVN_KERNEL_H
#define CONVN_KERNEL_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "FekgClus_types.h"

// Function Declarations
extern void eml_conv2(emxArray_real_T *C, const emxArray_real_T *A, const double
                      B[8], int firstRowC, int lastRowC);

#endif

//
// File trailer for convn_kernel.h
//
// [EOF]
//
