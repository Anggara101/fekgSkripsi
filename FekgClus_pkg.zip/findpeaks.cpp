//
// File: findpeaks.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "findpeaks.h"
#include "FekgClus_emxutil.h"
#include "eml_setop.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *Yin
//                emxArray_real_T *Ypk
//                emxArray_real_T *Xpk
// Return Type  : void
//
void findpeaks(const emxArray_real_T *Yin, emxArray_real_T *Ypk, emxArray_real_T
               *Xpk)
{
  emxArray_real_T *y;
  int k;
  int nPk;
  emxArray_real_T *x;
  emxArray_int32_T *idx;
  emxArray_int32_T *iFinite;
  emxArray_int32_T *iInfinite;
  unsigned int Yin_idx_0;
  int nInf;
  char dir;
  int kfirst;
  double ykfirst;
  boolean_T isinfykfirst;
  double yk;
  emxArray_uint32_T *b_iFinite;
  boolean_T isinfyk;
  char previousdir;
  emxArray_int32_T *iPk;
  emxArray_int32_T *c;
  emxArray_int32_T *b_y;
  emxInit_real_T(&y, 2);
  if (Yin->size[1] < 1) {
    k = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 0;
    emxEnsureCapacity_real_T(y, k);
  } else {
    k = Yin->size[1];
    nPk = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = (int)((double)k - 1.0) + 1;
    emxEnsureCapacity_real_T(y, nPk);
    nPk = (int)((double)k - 1.0);
    for (k = 0; k <= nPk; k++) {
      y->data[y->size[0] * k] = 1.0 + (double)k;
    }
  }

  emxInit_real_T1(&x, 1);
  k = x->size[0];
  x->size[0] = y->size[1];
  emxEnsureCapacity_real_T1(x, k);
  nPk = y->size[1];
  for (k = 0; k < nPk; k++) {
    x->data[k] = y->data[y->size[0] * k];
  }

  emxFree_real_T(&y);
  emxInit_int32_T(&idx, 1);
  emxInit_int32_T(&iFinite, 1);
  emxInit_int32_T(&iInfinite, 1);
  Yin_idx_0 = (unsigned int)Yin->size[1];
  k = iFinite->size[0];
  iFinite->size[0] = (int)Yin_idx_0;
  emxEnsureCapacity_int32_T(iFinite, k);
  Yin_idx_0 = (unsigned int)Yin->size[1];
  k = iInfinite->size[0];
  iInfinite->size[0] = (int)Yin_idx_0;
  emxEnsureCapacity_int32_T(iInfinite, k);
  nPk = 0;
  nInf = 0;
  dir = 'n';
  kfirst = -1;
  ykfirst = rtInf;
  isinfykfirst = true;
  for (k = 0; k + 1 <= Yin->size[1]; k++) {
    yk = Yin->data[k];
    if (rtIsNaN(Yin->data[k])) {
      yk = rtInf;
      isinfyk = true;
    } else if (rtIsInf(Yin->data[k]) && (Yin->data[k] > 0.0)) {
      isinfyk = true;
      nInf++;
      iInfinite->data[nInf - 1] = k + 1;
    } else {
      isinfyk = false;
    }

    if (yk != ykfirst) {
      previousdir = dir;
      if (isinfyk || isinfykfirst) {
        dir = 'n';
      } else if (yk < ykfirst) {
        dir = 'd';
        if (('d' != previousdir) && (previousdir == 'i')) {
          nPk++;
          iFinite->data[nPk - 1] = kfirst + 1;
        }
      } else {
        dir = 'i';
      }

      ykfirst = yk;
      kfirst = k;
      isinfykfirst = isinfyk;
    }
  }

  if (1 > nPk) {
    nPk = 0;
  }

  emxInit_uint32_T(&b_iFinite, 1);
  k = b_iFinite->size[0];
  b_iFinite->size[0] = iFinite->size[0];
  emxEnsureCapacity_uint32_T(b_iFinite, k);
  kfirst = iFinite->size[0];
  for (k = 0; k < kfirst; k++) {
    b_iFinite->data[k] = (unsigned int)iFinite->data[k];
  }

  k = iFinite->size[0];
  iFinite->size[0] = nPk;
  emxEnsureCapacity_int32_T(iFinite, k);
  for (k = 0; k < nPk; k++) {
    iFinite->data[k] = (int)b_iFinite->data[k];
  }

  if (1 > nInf) {
    nPk = 0;
  } else {
    nPk = nInf;
  }

  k = b_iFinite->size[0];
  b_iFinite->size[0] = iInfinite->size[0];
  emxEnsureCapacity_uint32_T(b_iFinite, k);
  kfirst = iInfinite->size[0];
  for (k = 0; k < kfirst; k++) {
    b_iFinite->data[k] = (unsigned int)iInfinite->data[k];
  }

  k = iInfinite->size[0];
  iInfinite->size[0] = nPk;
  emxEnsureCapacity_int32_T(iInfinite, k);
  for (k = 0; k < nPk; k++) {
    iInfinite->data[k] = (int)b_iFinite->data[k];
  }

  emxInit_int32_T(&iPk, 1);
  k = iPk->size[0];
  iPk->size[0] = iFinite->size[0];
  emxEnsureCapacity_int32_T(iPk, k);
  nPk = 0;
  for (k = 0; k + 1 <= iFinite->size[0]; k++) {
    if (Yin->data[iFinite->data[k] - 1] > rtMinusInf) {
      if ((Yin->data[iFinite->data[k] - 2] > Yin->data[iFinite->data[k]]) ||
          rtIsNaN(Yin->data[iFinite->data[k]])) {
        ykfirst = Yin->data[iFinite->data[k] - 2];
      } else {
        ykfirst = Yin->data[iFinite->data[k]];
      }

      if (Yin->data[iFinite->data[k] - 1] - ykfirst >= 0.0) {
        nPk++;
        iPk->data[nPk - 1] = iFinite->data[k];
      }
    }
  }

  if (1 > nPk) {
    nPk = 0;
  }

  k = b_iFinite->size[0];
  b_iFinite->size[0] = iPk->size[0];
  emxEnsureCapacity_uint32_T(b_iFinite, k);
  kfirst = iPk->size[0];
  for (k = 0; k < kfirst; k++) {
    b_iFinite->data[k] = (unsigned int)iPk->data[k];
  }

  k = iPk->size[0];
  iPk->size[0] = nPk;
  emxEnsureCapacity_int32_T(iPk, k);
  for (k = 0; k < nPk; k++) {
    iPk->data[k] = (int)b_iFinite->data[k];
  }

  emxFree_uint32_T(&b_iFinite);
  emxInit_int32_T(&c, 1);
  emxInit_int32_T1(&b_y, 2);
  do_vectors(iPk, iInfinite, c, idx, iFinite);
  nPk = c->size[0];
  emxFree_int32_T(&iInfinite);
  emxFree_int32_T(&iFinite);
  if (nPk < 1) {
    kfirst = 0;
  } else {
    kfirst = nPk;
  }

  k = b_y->size[0] * b_y->size[1];
  b_y->size[0] = 1;
  b_y->size[1] = kfirst;
  emxEnsureCapacity_int32_T1(b_y, k);
  if (kfirst > 0) {
    b_y->data[0] = 1;
    nPk = 1;
    for (k = 2; k <= kfirst; k++) {
      nPk++;
      b_y->data[k - 1] = nPk;
    }
  }

  k = idx->size[0];
  idx->size[0] = b_y->size[1];
  emxEnsureCapacity_int32_T(idx, k);
  nPk = b_y->size[1];
  for (k = 0; k < nPk; k++) {
    idx->data[k] = b_y->data[b_y->size[0] * k];
  }

  emxFree_int32_T(&b_y);
  if (idx->size[0] > Yin->size[1]) {
    k = idx->size[0];
    idx->size[0] = Yin->size[1];
    emxEnsureCapacity_int32_T(idx, k);
  }

  k = iPk->size[0];
  iPk->size[0] = idx->size[0];
  emxEnsureCapacity_int32_T(iPk, k);
  nPk = idx->size[0];
  for (k = 0; k < nPk; k++) {
    iPk->data[k] = c->data[idx->data[k] - 1];
  }

  emxFree_int32_T(&c);
  emxFree_int32_T(&idx);
  k = Ypk->size[0] * Ypk->size[1];
  Ypk->size[0] = 1;
  Ypk->size[1] = iPk->size[0];
  emxEnsureCapacity_real_T(Ypk, k);
  nPk = iPk->size[0];
  for (k = 0; k < nPk; k++) {
    Ypk->data[Ypk->size[0] * k] = Yin->data[iPk->data[k] - 1];
  }

  k = Xpk->size[0] * Xpk->size[1];
  Xpk->size[0] = 1;
  Xpk->size[1] = iPk->size[0];
  emxEnsureCapacity_real_T(Xpk, k);
  nPk = iPk->size[0];
  for (k = 0; k < nPk; k++) {
    Xpk->data[Xpk->size[0] * k] = x->data[iPk->data[k] - 1];
  }

  emxFree_real_T(&x);
  emxFree_int32_T(&iPk);
}

//
// File trailer for findpeaks.cpp
//
// [EOF]
//
