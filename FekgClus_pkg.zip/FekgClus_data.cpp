//
// File: FekgClus_data.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "FekgClus_data.h"

// Variable Definitions
unsigned int state[625];

//
// File trailer for FekgClus_data.cpp
//
// [EOF]
//
