//
// File: wavedec.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "wavedec.h"
#include "FekgClus_emxutil.h"
#include "dwt.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *x
//                emxArray_real_T *c
//                double l[12]
// Return Type  : void
//
void wavedec(const emxArray_real_T *x, emxArray_real_T *c, double l[12])
{
  int i1;
  emxArray_real_T *xv;
  int x_idx_0;
  emxArray_real_T *d;
  emxArray_real_T *b_xv;
  int loop_ub;
  i1 = c->size[0] * c->size[1];
  c->size[0] = 1;
  c->size[1] = 0;
  emxEnsureCapacity_real_T(c, i1);
  for (i1 = 0; i1 < 12; i1++) {
    l[i1] = 0.0;
  }

  emxInit_real_T(&xv, 2);
  x_idx_0 = x->size[1];
  i1 = xv->size[0] * xv->size[1];
  xv->size[0] = 1;
  xv->size[1] = x_idx_0;
  emxEnsureCapacity_real_T(xv, i1);
  for (i1 = 0; i1 < x_idx_0; i1++) {
    xv->data[xv->size[0] * i1] = x->data[i1];
  }

  if (x->size[1] != 0) {
    l[11] = x->size[1];
    emxInit_real_T(&d, 2);
    emxInit_real_T(&b_xv, 2);
    for (x_idx_0 = 0; x_idx_0 < 10; x_idx_0++) {
      i1 = b_xv->size[0] * b_xv->size[1];
      b_xv->size[0] = 1;
      b_xv->size[1] = xv->size[1];
      emxEnsureCapacity_real_T(b_xv, i1);
      loop_ub = xv->size[0] * xv->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        b_xv->data[i1] = xv->data[i1];
      }

      dwt(b_xv, xv, d);
      i1 = b_xv->size[0] * b_xv->size[1];
      b_xv->size[0] = 1;
      b_xv->size[1] = d->size[1] + c->size[1];
      emxEnsureCapacity_real_T(b_xv, i1);
      loop_ub = d->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        b_xv->data[b_xv->size[0] * i1] = d->data[d->size[0] * i1];
      }

      loop_ub = c->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        b_xv->data[b_xv->size[0] * (i1 + d->size[1])] = c->data[c->size[0] * i1];
      }

      i1 = c->size[0] * c->size[1];
      c->size[0] = 1;
      c->size[1] = b_xv->size[1];
      emxEnsureCapacity_real_T(c, i1);
      loop_ub = b_xv->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        c->data[c->size[0] * i1] = b_xv->data[b_xv->size[0] * i1];
      }

      l[10 - x_idx_0] = d->size[1];
    }

    emxFree_real_T(&d);
    i1 = b_xv->size[0] * b_xv->size[1];
    b_xv->size[0] = 1;
    b_xv->size[1] = xv->size[1] + c->size[1];
    emxEnsureCapacity_real_T(b_xv, i1);
    loop_ub = xv->size[1];
    for (i1 = 0; i1 < loop_ub; i1++) {
      b_xv->data[b_xv->size[0] * i1] = xv->data[xv->size[0] * i1];
    }

    loop_ub = c->size[1];
    for (i1 = 0; i1 < loop_ub; i1++) {
      b_xv->data[b_xv->size[0] * (i1 + xv->size[1])] = c->data[c->size[0] * i1];
    }

    i1 = c->size[0] * c->size[1];
    c->size[0] = 1;
    c->size[1] = b_xv->size[1];
    emxEnsureCapacity_real_T(c, i1);
    loop_ub = b_xv->size[1];
    for (i1 = 0; i1 < loop_ub; i1++) {
      c->data[c->size[0] * i1] = b_xv->data[b_xv->size[0] * i1];
    }

    emxFree_real_T(&b_xv);
    l[0] = xv->size[1];
  }

  emxFree_real_T(&xv);
}

//
// File trailer for wavedec.cpp
//
// [EOF]
//
