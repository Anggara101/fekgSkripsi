//
// File: eml_rand_mt19937ar_stateful.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//
#ifndef EML_RAND_MT19937AR_STATEFUL_H
#define EML_RAND_MT19937AR_STATEFUL_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "FekgClus_types.h"

// Function Declarations
extern void c_eml_rand_mt19937ar_stateful_i();

#endif

//
// File trailer for eml_rand_mt19937ar_stateful.h
//
// [EOF]
//
