//
// File: kmeans.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "kmeans.h"
#include "FekgClus_emxutil.h"
#include "rand.h"
#include "rdivide.h"

// Function Declarations
static void b_distfun(emxArray_real_T *D, const emxArray_real_T *X, const double
                      C[3], const int crows[3], int ncrows);
static void batchUpdate(const emxArray_real_T *X, emxArray_int32_T *idx, double
  C[3], emxArray_real_T *D, int counts[3], boolean_T *converged, int *iter);
static void distfun(emxArray_real_T *D, const emxArray_real_T *X, const double
                    C[3], int crows);
static void gcentroids(double C[3], int counts[3], const emxArray_real_T *X,
  const emxArray_int32_T *idx, const int clusters[3], int nclusters);
static void local_kmeans(const emxArray_real_T *X, emxArray_int32_T *idxbest,
  double Cbest[3]);
static void mindim2(const emxArray_real_T *D, emxArray_real_T *d,
                    emxArray_int32_T *idx);

// Function Definitions

//
// Arguments    : emxArray_real_T *D
//                const emxArray_real_T *X
//                const double C[3]
//                const int crows[3]
//                int ncrows
// Return Type  : void
//
static void b_distfun(emxArray_real_T *D, const emxArray_real_T *X, const double
                      C[3], const int crows[3], int ncrows)
{
  int i;
  int cr;
  int r;
  double a;
  for (i = 1; i <= ncrows; i++) {
    cr = crows[i - 1] - 1;
    for (r = 0; r + 1 <= X->size[0]; r++) {
      a = X->data[r] - C[cr];
      D->data[r + D->size[0] * cr] = a * a;
    }
  }
}

//
// Arguments    : const emxArray_real_T *X
//                emxArray_int32_T *idx
//                double C[3]
//                emxArray_real_T *D
//                int counts[3]
//                boolean_T *converged
//                int *iter
// Return Type  : void
//
static void batchUpdate(const emxArray_real_T *X, emxArray_int32_T *idx, double
  C[3], emxArray_real_T *D, int counts[3], boolean_T *converged, int *iter)
{
  int n;
  int i;
  emxArray_int32_T *previdx;
  int empties[3];
  int j;
  int lonely;
  emxArray_int32_T *moved;
  int nchanged;
  int changed[3];
  double prevtotsumD;
  emxArray_real_T *d;
  emxArray_int32_T *nidx;
  emxArray_boolean_T *b;
  int exitg1;
  int nempty;
  double totsumD;
  int from;
  int nMoved;
  boolean_T exitg2;
  unsigned int unnamed_idx_0;
  n = X->size[0];
  for (i = 0; i < 3; i++) {
    empties[i] = 0;
  }

  emxInit_int32_T(&previdx, 1);
  j = previdx->size[0];
  previdx->size[0] = X->size[0];
  emxEnsureCapacity_int32_T(previdx, j);
  lonely = X->size[0];
  for (j = 0; j < lonely; j++) {
    previdx->data[j] = 0;
  }

  emxInit_int32_T(&moved, 1);
  j = moved->size[0];
  moved->size[0] = X->size[0];
  emxEnsureCapacity_int32_T(moved, j);
  lonely = X->size[0];
  for (j = 0; j < lonely; j++) {
    moved->data[j] = 0;
  }

  for (j = 0; j < 3; j++) {
    changed[j] = j + 1;
  }

  nchanged = 3;
  prevtotsumD = rtInf;
  *iter = 0;
  *converged = false;
  emxInit_real_T1(&d, 1);
  emxInit_int32_T(&nidx, 1);
  emxInit_boolean_T(&b, 1);
  do {
    exitg1 = 0;
    (*iter)++;
    gcentroids(C, counts, X, idx, changed, nchanged);
    b_distfun(D, X, C, changed, nchanged);
    nempty = 0;
    for (j = 0; j + 1 <= nchanged; j++) {
      if (counts[changed[j] - 1] == 0) {
        nempty++;
        empties[nempty - 1] = changed[j];
      }
    }

    if (nempty > 0) {
      for (i = 0; i + 1 <= nempty; i++) {
        j = d->size[0];
        d->size[0] = n;
        emxEnsureCapacity_real_T1(d, j);
        d->data[0] = D->data[D->size[0] * (idx->data[0] - 1)];
        totsumD = d->data[0];
        lonely = 0;
        for (j = 0; j + 1 <= n; j++) {
          d->data[j] = D->data[j + D->size[0] * (idx->data[j] - 1)];
          if (d->data[j] > totsumD) {
            totsumD = d->data[j];
            lonely = j;
          }
        }

        from = idx->data[lonely];
        if (counts[idx->data[lonely] - 1] < 2) {
          j = 1;
          exitg2 = false;
          while ((!exitg2) && (j <= n)) {
            if (counts[j - 1] > 1) {
              from = j;
              exitg2 = true;
            } else {
              j++;
            }
          }

          j = 0;
          exitg2 = false;
          while ((!exitg2) && (j + 1 <= n)) {
            if (idx->data[j] == from) {
              lonely = j;
              exitg2 = true;
            } else {
              j++;
            }
          }
        }

        C[empties[i] - 1] = X->data[lonely];
        counts[empties[i] - 1] = 1;
        idx->data[lonely] = empties[i];
        distfun(D, X, C, empties[i]);
        counts[from - 1] = 0;
        C[from - 1] = rtNaN;
        nMoved = 0;
        C[from - 1] = 0.0;
        for (j = 0; j + 1 <= X->size[0]; j++) {
          if (idx->data[j] == from) {
            nMoved++;
            C[from - 1] += X->data[j];
          }
        }

        counts[from - 1] = nMoved;
        C[from - 1] /= (double)nMoved;
        distfun(D, X, C, from);
        if (nchanged < 3) {
          j = 0;
          exitg2 = false;
          while ((!exitg2) && ((j + 1 <= nchanged) && (!(from == changed[j]))))
          {
            if (from > changed[j]) {
              for (nMoved = nchanged; nMoved >= j + 1; nMoved--) {
                changed[nMoved] = changed[nMoved - 1];
              }

              changed[j] = from;
              nchanged++;
              exitg2 = true;
            } else {
              j++;
            }
          }
        }
      }
    }

    totsumD = 0.0;
    for (i = 0; i + 1 <= n; i++) {
      totsumD += D->data[i + D->size[0] * (idx->data[i] - 1)];
    }

    if (prevtotsumD <= totsumD) {
      j = idx->size[0];
      idx->size[0] = previdx->size[0];
      emxEnsureCapacity_int32_T(idx, j);
      lonely = previdx->size[0];
      for (j = 0; j < lonely; j++) {
        idx->data[j] = previdx->data[j];
      }

      gcentroids(C, counts, X, previdx, changed, nchanged);
      (*iter)--;
      exitg1 = 1;
    } else if (*iter >= 100) {
      exitg1 = 1;
    } else {
      j = previdx->size[0];
      previdx->size[0] = idx->size[0];
      emxEnsureCapacity_int32_T(previdx, j);
      lonely = idx->size[0];
      for (j = 0; j < lonely; j++) {
        previdx->data[j] = idx->data[j];
      }

      prevtotsumD = totsumD;
      mindim2(D, d, nidx);
      nMoved = 0;
      for (i = 0; i + 1 <= n; i++) {
        if ((nidx->data[i] != previdx->data[i]) && (D->data[i + D->size[0] *
             (previdx->data[i] - 1)] > d->data[i])) {
          nMoved++;
          moved->data[nMoved - 1] = i + 1;
          idx->data[i] = nidx->data[i];
        }
      }

      if (nMoved == 0) {
        *converged = true;
        exitg1 = 1;
      } else {
        unnamed_idx_0 = (unsigned int)moved->size[0];
        j = b->size[0];
        b->size[0] = (int)unnamed_idx_0;
        emxEnsureCapacity_boolean_T(b, j);
        lonely = (int)unnamed_idx_0;
        for (j = 0; j < lonely; j++) {
          b->data[j] = false;
        }

        for (j = 0; j + 1 <= nMoved; j++) {
          b->data[idx->data[moved->data[j] - 1] - 1] = true;
          b->data[previdx->data[moved->data[j] - 1] - 1] = true;
        }

        nchanged = 0;
        for (j = 1; j <= b->size[0]; j++) {
          if (b->data[j - 1]) {
            nchanged++;
            changed[nchanged - 1] = j;
          }
        }
      }
    }
  } while (exitg1 == 0);

  emxFree_boolean_T(&b);
  emxFree_int32_T(&nidx);
  emxFree_real_T(&d);
  emxFree_int32_T(&moved);
  emxFree_int32_T(&previdx);
}

//
// Arguments    : emxArray_real_T *D
//                const emxArray_real_T *X
//                const double C[3]
//                int crows
// Return Type  : void
//
static void distfun(emxArray_real_T *D, const emxArray_real_T *X, const double
                    C[3], int crows)
{
  int r;
  double a;
  for (r = 0; r + 1 <= X->size[0]; r++) {
    a = X->data[r] - C[crows - 1];
    D->data[r + D->size[0] * (crows - 1)] = a * a;
  }
}

//
// Arguments    : double C[3]
//                int counts[3]
//                const emxArray_real_T *X
//                const emxArray_int32_T *idx
//                const int clusters[3]
//                int nclusters
// Return Type  : void
//
static void gcentroids(double C[3], int counts[3], const emxArray_real_T *X,
  const emxArray_int32_T *idx, const int clusters[3], int nclusters)
{
  int ic;
  int clic;
  int cc;
  int i;
  for (ic = 0; ic + 1 <= nclusters; ic++) {
    counts[clusters[ic] - 1] = 0;
    C[clusters[ic] - 1] = rtNaN;
  }

  for (ic = 0; ic + 1 <= nclusters; ic++) {
    clic = clusters[ic];
    cc = 0;
    C[clusters[ic] - 1] = 0.0;
    for (i = 0; i + 1 <= X->size[0]; i++) {
      if (idx->data[i] == clic) {
        cc++;
        C[clic - 1] += X->data[i];
      }
    }

    counts[clusters[ic] - 1] = cc;
    C[clusters[ic] - 1] /= (double)cc;
  }
}

//
// Arguments    : const emxArray_real_T *X
//                emxArray_int32_T *idxbest
//                double Cbest[3]
// Return Type  : void
//
static void local_kmeans(const emxArray_real_T *X, emxArray_int32_T *idxbest,
  double Cbest[3])
{
  int n;
  double b_index;
  int i;
  emxArray_real_T *D;
  int low_i;
  emxArray_real_T *d;
  emxArray_real_T *sampleDist;
  boolean_T DNeedsComputing;
  int c;
  emxArray_real_T *b_sampleDist;
  boolean_T exitg1;
  int crows[3];
  int high_i;
  int nonEmpties[3];
  double pt;
  double u;
  int mid_i;
  n = X->size[0];
  b_index = b_rand();
  for (i = 0; i < 3; i++) {
    Cbest[i] = 0.0;
  }

  emxInit_real_T(&D, 2);
  Cbest[0] = X->data[(int)(1.0 + std::floor(b_index * (double)X->size[0])) - 1];
  i = D->size[0] * D->size[1];
  D->size[0] = X->size[0];
  D->size[1] = 3;
  emxEnsureCapacity_real_T(D, i);
  low_i = X->size[0] * 3;
  for (i = 0; i < low_i; i++) {
    D->data[i] = 0.0;
  }

  emxInit_real_T1(&d, 1);
  distfun(D, X, Cbest, 1);
  low_i = D->size[0];
  i = d->size[0];
  d->size[0] = low_i;
  emxEnsureCapacity_real_T1(d, i);
  for (i = 0; i < low_i; i++) {
    d->data[i] = D->data[i];
  }

  i = idxbest->size[0];
  idxbest->size[0] = X->size[0];
  emxEnsureCapacity_int32_T(idxbest, i);
  low_i = X->size[0];
  for (i = 0; i < low_i; i++) {
    idxbest->data[i] = 1;
  }

  emxInit_real_T1(&sampleDist, 1);
  i = sampleDist->size[0];
  sampleDist->size[0] = X->size[0] + 1;
  emxEnsureCapacity_real_T1(sampleDist, i);
  low_i = X->size[0];
  for (i = 0; i <= low_i; i++) {
    sampleDist->data[i] = 0.0;
  }

  DNeedsComputing = false;
  c = 2;
  emxInit_real_T1(&b_sampleDist, 1);
  exitg1 = false;
  while ((!exitg1) && (c < 4)) {
    b_index = 0.0;
    sampleDist->data[0] = 0.0;
    for (i = 0; i + 1 <= n; i++) {
      sampleDist->data[i + 1] = sampleDist->data[i] + d->data[i];
      b_index += d->data[i];
    }

    if ((b_index == 0.0) || (!((!rtIsInf(b_index)) && (!rtIsNaN(b_index))))) {
      high_i = 0;
      i = idxbest->size[0];
      idxbest->size[0] = n;
      emxEnsureCapacity_int32_T(idxbest, i);
      for (i = 0; i < n; i++) {
        idxbest->data[i] = 0;
      }

      for (low_i = 0; low_i <= 3 - c; low_i++) {
        i = 4 - (c + low_i);
        b_index = n - high_i;
        pt = (double)i / b_index;
        u = b_rand();
        while (u > pt) {
          high_i++;
          b_index--;
          pt += (1.0 - pt) * ((double)i / b_index);
        }

        high_i++;
        b_index = b_rand() * ((double)low_i + 1.0);
        b_index = std::floor(b_index);
        idxbest->data[low_i] = idxbest->data[(int)b_index];
        idxbest->data[(int)b_index] = high_i;
      }

      for (i = c; i < 4; i++) {
        Cbest[i - 1] = X->data[idxbest->data[i - c] - 1];
      }

      DNeedsComputing = true;
      exitg1 = true;
    } else {
      i = b_sampleDist->size[0];
      b_sampleDist->size[0] = sampleDist->size[0];
      emxEnsureCapacity_real_T1(b_sampleDist, i);
      low_i = sampleDist->size[0];
      for (i = 0; i < low_i; i++) {
        b_sampleDist->data[i] = sampleDist->data[i];
      }

      rdivide(b_sampleDist, b_index, sampleDist);
      b_index = b_rand();
      low_i = 1;
      i = 2;
      high_i = sampleDist->size[0];
      while (high_i > i) {
        mid_i = (low_i >> 1) + (high_i >> 1);
        if (((low_i & 1) == 1) && ((high_i & 1) == 1)) {
          mid_i++;
        }

        if (b_index >= sampleDist->data[mid_i - 1]) {
          low_i = mid_i;
          i = mid_i + 1;
        } else {
          high_i = mid_i;
        }
      }

      b_index = sampleDist->data[low_i - 1];
      if (sampleDist->data[low_i - 1] < 1.0) {
        while ((low_i <= n) && (sampleDist->data[low_i] <= b_index)) {
          low_i++;
        }
      } else {
        while ((low_i >= 2) && (sampleDist->data[low_i - 2] >= b_index)) {
          low_i--;
        }
      }

      Cbest[c - 1] = X->data[low_i - 1];
      distfun(D, X, Cbest, c);
      for (i = 0; i + 1 <= n; i++) {
        if (D->data[i + D->size[0] * (c - 1)] < d->data[i]) {
          d->data[i] = D->data[i + D->size[0] * (c - 1)];
          idxbest->data[i] = c;
        }
      }

      c++;
    }
  }

  emxFree_real_T(&b_sampleDist);
  emxFree_real_T(&sampleDist);
  if (DNeedsComputing) {
    for (c = 0; c < 3; c++) {
      crows[c] = c + 1;
    }

    b_distfun(D, X, Cbest, crows, 3);
    mindim2(D, d, idxbest);
  }

  emxFree_real_T(&d);
  for (i = 0; i < 3; i++) {
    crows[i] = 0;
  }

  for (i = 0; i + 1 <= n; i++) {
    crows[idxbest->data[i] - 1]++;
  }

  for (i = 0; i < 3; i++) {
    nonEmpties[i] = 0;
  }

  batchUpdate(X, idxbest, Cbest, D, crows, &DNeedsComputing, &low_i);
  low_i = 0;
  for (i = 0; i < 3; i++) {
    if (crows[i] > 0) {
      low_i++;
      nonEmpties[low_i - 1] = i + 1;
    }
  }

  b_distfun(D, X, Cbest, nonEmpties, low_i);
  emxFree_real_T(&D);
}

//
// Arguments    : const emxArray_real_T *D
//                emxArray_real_T *d
//                emxArray_int32_T *idx
// Return Type  : void
//
static void mindim2(const emxArray_real_T *D, emxArray_real_T *d,
                    emxArray_int32_T *idx)
{
  int outsize_idx_0;
  int i;
  outsize_idx_0 = D->size[0];
  i = d->size[0];
  d->size[0] = outsize_idx_0;
  emxEnsureCapacity_real_T1(d, i);
  for (i = 0; i < outsize_idx_0; i++) {
    d->data[i] = rtInf;
  }

  i = idx->size[0];
  idx->size[0] = D->size[0];
  emxEnsureCapacity_int32_T(idx, i);
  outsize_idx_0 = D->size[0];
  for (i = 0; i < outsize_idx_0; i++) {
    idx->data[i] = 1;
  }

  for (outsize_idx_0 = 0; outsize_idx_0 < 3; outsize_idx_0++) {
    for (i = 0; i + 1 <= D->size[0]; i++) {
      if (D->data[i + D->size[0] * outsize_idx_0] < d->data[i]) {
        idx->data[i] = outsize_idx_0 + 1;
        d->data[i] = D->data[i + D->size[0] * outsize_idx_0];
      }
    }
  }
}

//
// Arguments    : emxArray_real_T *X
//                emxArray_real_T *idxbest
//                double Cbest[3]
// Return Type  : void
//
void kmeans(emxArray_real_T *X, emxArray_real_T *idxbest, double Cbest[3])
{
  emxArray_boolean_T *wasnan;
  int n;
  int i;
  int j;
  boolean_T hadnans;
  emxArray_int32_T *idx;
  int end;
  emxArray_real_T *b_X;
  emxInit_boolean_T(&wasnan, 1);
  n = X->size[0];
  i = wasnan->size[0];
  wasnan->size[0] = X->size[0];
  emxEnsureCapacity_boolean_T(wasnan, i);
  j = X->size[0];
  for (i = 0; i < j; i++) {
    wasnan->data[i] = false;
  }

  hadnans = false;
  for (i = 0; i + 1 <= n; i++) {
    if (rtIsNaN(X->data[i])) {
      hadnans = true;
      wasnan->data[i] = true;
    }
  }

  emxInit_int32_T(&idx, 1);
  if (hadnans) {
    end = wasnan->size[0] - 1;
    j = 0;
    for (i = 0; i <= end; i++) {
      if (!wasnan->data[i]) {
        j++;
      }
    }

    i = idx->size[0];
    idx->size[0] = j;
    emxEnsureCapacity_int32_T(idx, i);
    j = 0;
    for (i = 0; i <= end; i++) {
      if (!wasnan->data[i]) {
        idx->data[j] = i + 1;
        j++;
      }
    }

    emxInit_real_T1(&b_X, 1);
    i = b_X->size[0];
    b_X->size[0] = idx->size[0];
    emxEnsureCapacity_real_T1(b_X, i);
    j = idx->size[0];
    for (i = 0; i < j; i++) {
      b_X->data[i] = X->data[idx->data[i] - 1];
    }

    i = X->size[0];
    X->size[0] = b_X->size[0];
    emxEnsureCapacity_real_T1(X, i);
    j = b_X->size[0];
    for (i = 0; i < j; i++) {
      X->data[i] = b_X->data[i];
    }

    emxFree_real_T(&b_X);
  }

  local_kmeans(X, idx, Cbest);
  if (hadnans) {
    j = -1;
    i = idxbest->size[0];
    idxbest->size[0] = n;
    emxEnsureCapacity_real_T1(idxbest, i);
    for (i = 0; i + 1 <= n; i++) {
      if (wasnan->data[i]) {
        idxbest->data[i] = rtNaN;
      } else {
        j++;
        idxbest->data[i] = idx->data[j];
      }
    }
  } else {
    i = idxbest->size[0];
    idxbest->size[0] = idx->size[0];
    emxEnsureCapacity_real_T1(idxbest, i);
    j = idx->size[0];
    for (i = 0; i < j; i++) {
      idxbest->data[i] = idx->data[i];
    }
  }

  emxFree_int32_T(&idx);
  emxFree_boolean_T(&wasnan);
}

//
// File trailer for kmeans.cpp
//
// [EOF]
//
