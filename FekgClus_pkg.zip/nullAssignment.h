//
// File: nullAssignment.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//
#ifndef NULLASSIGNMENT_H
#define NULLASSIGNMENT_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "FekgClus_types.h"

// Function Declarations
extern void nullAssignment(emxArray_real_T *x, int idx);

#endif

//
// File trailer for nullAssignment.h
//
// [EOF]
//
