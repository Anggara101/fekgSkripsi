//
// File: rdivide.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "rdivide.h"
#include "FekgClus_emxutil.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *x
//                double y
//                emxArray_real_T *z
// Return Type  : void
//
void rdivide(const emxArray_real_T *x, double y, emxArray_real_T *z)
{
  int i7;
  int loop_ub;
  i7 = z->size[0];
  z->size[0] = x->size[0];
  emxEnsureCapacity_real_T1(z, i7);
  loop_ub = x->size[0];
  for (i7 = 0; i7 < loop_ub; i7++) {
    z->data[i7] = x->data[i7] / y;
  }
}

//
// File trailer for rdivide.cpp
//
// [EOF]
//
