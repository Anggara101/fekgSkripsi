//
// File: dwt.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "dwt.h"
#include "FekgClus_emxutil.h"
#include "convn_kernel.h"

// Function Declarations
static int div_s32(int numerator, int denominator);

// Function Definitions

//
// Arguments    : int numerator
//                int denominator
// Return Type  : int
//
static int div_s32(int numerator, int denominator)
{
  int quotient;
  unsigned int absNumerator;
  unsigned int absDenominator;
  boolean_T quotientNeedsNegation;
  if (denominator == 0) {
    if (numerator >= 0) {
      quotient = MAX_int32_T;
    } else {
      quotient = MIN_int32_T;
    }
  } else {
    if (numerator < 0) {
      absNumerator = ~(unsigned int)numerator + 1U;
    } else {
      absNumerator = (unsigned int)numerator;
    }

    if (denominator < 0) {
      absDenominator = ~(unsigned int)denominator + 1U;
    } else {
      absDenominator = (unsigned int)denominator;
    }

    quotientNeedsNegation = ((numerator < 0) != (denominator < 0));
    absNumerator /= absDenominator;
    if (quotientNeedsNegation) {
      quotient = -(int)absNumerator;
    } else {
      quotient = (int)absNumerator;
    }
  }

  return quotient;
}

//
// Arguments    : const emxArray_real_T *x
//                emxArray_real_T *a
//                emxArray_real_T *d
// Return Type  : void
//
void dwt(const emxArray_real_T *x, emxArray_real_T *a, emxArray_real_T *d)
{
  emxArray_real_T *y;
  emxArray_int32_T *J;
  int ik;
  int nx;
  int lx2;
  int loop_ub;
  emxArray_real_T *b_a;
  emxArray_real_T *r5;
  emxArray_real_T *z;
  static const double B[8] = { -0.075765714789273325, -0.02963552764599851,
    0.49761866763201545, 0.80373875180591614, 0.29785779560527736,
    -0.099219543576847216, -0.012603967262037833, 0.0322231006040427 };

  static const double b_B[8] = { -0.0322231006040427, -0.012603967262037833,
    0.099219543576847216, 0.29785779560527736, -0.80373875180591614,
    0.49761866763201545, 0.02963552764599851, -0.075765714789273325 };

  emxInit_real_T(&y, 2);
  if (x->size[1] == 0) {
    ik = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 14;
    emxEnsureCapacity_real_T(y, ik);
    for (ik = 0; ik < 14; ik++) {
      y->data[ik] = 0.0;
    }
  } else {
    emxInit_int32_T1(&J, 2);
    nx = x->size[1];
    lx2 = x->size[1] << 1;
    ik = J->size[0] * J->size[1];
    J->size[0] = 1;
    J->size[1] = 14 + x->size[1];
    emxEnsureCapacity_int32_T1(J, ik);
    loop_ub = 14 + x->size[1];
    for (ik = 0; ik < loop_ub; ik++) {
      J->data[ik] = 0;
    }

    if (x->size[1] < 7) {
      for (loop_ub = 1; loop_ub <= 7 - nx; loop_ub++) {
        if (lx2 == 0) {
          ik = 1;
        } else {
          ik = 8 - (loop_ub + lx2 * div_s32(7 - loop_ub, lx2));
        }

        if (ik > nx) {
          ik = (lx2 - ik) + 1;
        }

        J->data[loop_ub - 1] = ik;
      }

      for (loop_ub = 8 - x->size[1]; loop_ub < 8; loop_ub++) {
        J->data[loop_ub - 1] = 8 - loop_ub;
      }
    } else {
      for (loop_ub = 0; loop_ub < 7; loop_ub++) {
        J->data[loop_ub] = 7 - loop_ub;
      }
    }

    for (loop_ub = 1; loop_ub <= nx; loop_ub++) {
      J->data[6 + loop_ub] = loop_ub;
    }

    if (x->size[1] < 7) {
      for (loop_ub = 1; loop_ub <= nx; loop_ub++) {
        J->data[(nx + loop_ub) + 6] = (nx - loop_ub) + 1;
      }

      for (loop_ub = x->size[1] + 1; loop_ub < 8; loop_ub++) {
        ik = loop_ub - nx;
        if (ik > nx) {
          if (lx2 == 0) {
            ik = 1;
          } else {
            ik -= lx2 * div_s32(ik - 1, lx2);
          }

          if (ik > nx) {
            ik = (lx2 - ik) + 1;
          }
        }

        J->data[(nx + loop_ub) + 6] = ik;
      }
    } else {
      for (loop_ub = 0; loop_ub < 7; loop_ub++) {
        J->data[(nx + loop_ub) + 7] = nx - loop_ub;
      }
    }

    ik = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = J->size[1];
    emxEnsureCapacity_real_T(y, ik);
    loop_ub = J->size[1];
    for (ik = 0; ik < loop_ub; ik++) {
      y->data[y->size[0] * ik] = x->data[x->size[0] * (J->data[J->size[0] * ik]
        - 1)];
    }

    emxFree_int32_T(&J);
  }

  loop_ub = y->size[1];
  ik = a->size[0] * a->size[1];
  a->size[0] = 1;
  a->size[1] = loop_ub;
  emxEnsureCapacity_real_T(a, ik);
  for (ik = 0; ik < loop_ub; ik++) {
    a->data[a->size[0] * ik] = y->data[ik];
  }

  emxInit_real_T1(&b_a, 1);
  loop_ub = a->size[1];
  ik = b_a->size[0];
  b_a->size[0] = loop_ub;
  emxEnsureCapacity_real_T1(b_a, ik);
  for (ik = 0; ik < loop_ub; ik++) {
    b_a->data[ik] = a->data[a->size[0] * ik];
  }

  emxInit_real_T1(&r5, 1);
  ik = r5->size[0];
  r5->size[0] = b_a->size[0] - 7;
  emxEnsureCapacity_real_T1(r5, ik);
  loop_ub = b_a->size[0];
  for (ik = 0; ik <= loop_ub - 8; ik++) {
    r5->data[ik] = 0.0;
  }

  emxInit_real_T(&z, 2);
  eml_conv2(r5, b_a, B, 7, b_a->size[0] - 1);
  ik = z->size[0] * z->size[1];
  z->size[0] = 1;
  z->size[1] = r5->size[0];
  emxEnsureCapacity_real_T(z, ik);
  loop_ub = r5->size[0];
  for (ik = 0; ik < loop_ub; ik++) {
    z->data[z->size[0] * ik] = r5->data[ik];
  }

  ik = x->size[1] + 5;
  loop_ub = a->size[0] * a->size[1];
  a->size[0] = 1;
  a->size[1] = (ik >> 1) + 1;
  emxEnsureCapacity_real_T(a, loop_ub);
  loop_ub = ik >> 1;
  for (ik = 0; ik <= loop_ub; ik++) {
    a->data[a->size[0] * ik] = z->data[1 + (ik << 1)];
  }

  loop_ub = y->size[1];
  ik = z->size[0] * z->size[1];
  z->size[0] = 1;
  z->size[1] = loop_ub;
  emxEnsureCapacity_real_T(z, ik);
  for (ik = 0; ik < loop_ub; ik++) {
    z->data[z->size[0] * ik] = y->data[ik];
  }

  emxFree_real_T(&y);
  loop_ub = z->size[1];
  ik = b_a->size[0];
  b_a->size[0] = loop_ub;
  emxEnsureCapacity_real_T1(b_a, ik);
  for (ik = 0; ik < loop_ub; ik++) {
    b_a->data[ik] = z->data[z->size[0] * ik];
  }

  ik = r5->size[0];
  r5->size[0] = b_a->size[0] - 7;
  emxEnsureCapacity_real_T1(r5, ik);
  loop_ub = b_a->size[0];
  for (ik = 0; ik <= loop_ub - 8; ik++) {
    r5->data[ik] = 0.0;
  }

  eml_conv2(r5, b_a, b_B, 7, b_a->size[0] - 1);
  ik = z->size[0] * z->size[1];
  z->size[0] = 1;
  z->size[1] = r5->size[0];
  emxEnsureCapacity_real_T(z, ik);
  loop_ub = r5->size[0];
  emxFree_real_T(&b_a);
  for (ik = 0; ik < loop_ub; ik++) {
    z->data[z->size[0] * ik] = r5->data[ik];
  }

  emxFree_real_T(&r5);
  ik = x->size[1] + 5;
  loop_ub = d->size[0] * d->size[1];
  d->size[0] = 1;
  d->size[1] = (ik >> 1) + 1;
  emxEnsureCapacity_real_T(d, loop_ub);
  loop_ub = ik >> 1;
  for (ik = 0; ik <= loop_ub; ik++) {
    d->data[d->size[0] * ik] = z->data[1 + (ik << 1)];
  }

  emxFree_real_T(&z);
}

//
// File trailer for dwt.cpp
//
// [EOF]
//
