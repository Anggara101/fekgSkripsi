//
// File: thselect.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "thselect.h"
#include "FekgClus_emxutil.h"
#include "rdivide.h"
#include "repmat.h"
#include "sort1.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *x
// Return Type  : double
//
double thselect(const emxArray_real_T *x)
{
  double thr;
  emxArray_real_T *xc;
  int itmp;
  int ixstart;
  emxArray_real_T *sx;
  unsigned int xc_idx_0;
  emxArray_real_T *sx2;
  int n;
  emxArray_real_T *y;
  emxArray_real_T *b_y;
  double mtmp;
  emxArray_real_T *CS1;
  emxArray_real_T *b_xc;
  emxArray_real_T *r8;
  emxArray_real_T *r9;
  int ix;
  boolean_T exitg1;
  emxInit_real_T1(&xc, 1);
  itmp = xc->size[0];
  xc->size[0] = x->size[1];
  emxEnsureCapacity_real_T1(xc, itmp);
  ixstart = x->size[1];
  for (itmp = 0; itmp < ixstart; itmp++) {
    xc->data[itmp] = x->data[x->size[0] * itmp];
  }

  emxInit_real_T1(&sx, 1);
  xc_idx_0 = (unsigned int)xc->size[0];
  itmp = sx->size[0];
  sx->size[0] = (int)xc_idx_0;
  emxEnsureCapacity_real_T1(sx, itmp);
  for (ixstart = 0; ixstart + 1 <= xc->size[0]; ixstart++) {
    sx->data[ixstart] = std::abs(xc->data[ixstart]);
  }

  emxInit_real_T1(&sx2, 1);
  sort(sx);
  n = sx->size[0];
  ixstart = sx->size[0];
  itmp = sx2->size[0];
  sx2->size[0] = ixstart;
  emxEnsureCapacity_real_T1(sx2, itmp);
  for (ixstart = 0; ixstart + 1 <= n; ixstart++) {
    sx2->data[ixstart] = sx->data[ixstart] * sx->data[ixstart];
  }

  emxInit_real_T(&y, 2);
  if (xc->size[0] < 1) {
    itmp = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 0;
    emxEnsureCapacity_real_T(y, itmp);
  } else {
    itmp = xc->size[0];
    ixstart = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = (int)((double)itmp - 1.0) + 1;
    emxEnsureCapacity_real_T(y, ixstart);
    ixstart = (int)((double)itmp - 1.0);
    for (itmp = 0; itmp <= ixstart; itmp++) {
      y->data[y->size[0] * itmp] = 1.0 + (double)itmp;
    }
  }

  emxInit_real_T(&b_y, 2);
  if (xc->size[0] - 1 < 0) {
    itmp = b_y->size[0] * b_y->size[1];
    b_y->size[0] = 1;
    b_y->size[1] = 0;
    emxEnsureCapacity_real_T(b_y, itmp);
  } else {
    mtmp = (double)xc->size[0] - 1.0;
    itmp = b_y->size[0] * b_y->size[1];
    b_y->size[0] = 1;
    b_y->size[1] = (int)-(0.0 - mtmp) + 1;
    emxEnsureCapacity_real_T(b_y, itmp);
    ixstart = (int)-(0.0 - mtmp);
    for (itmp = 0; itmp <= ixstart; itmp++) {
      b_y->data[b_y->size[0] * itmp] = mtmp - (double)itmp;
    }
  }

  emxInit_real_T1(&CS1, 1);
  itmp = CS1->size[0];
  CS1->size[0] = sx2->size[0];
  emxEnsureCapacity_real_T1(CS1, itmp);
  ixstart = sx2->size[0];
  for (itmp = 0; itmp < ixstart; itmp++) {
    CS1->data[itmp] = sx2->data[itmp];
  }

  if ((!(sx2->size[0] == 0)) && (sx2->size[0] > 1)) {
    for (ixstart = 1; ixstart < sx2->size[0]; ixstart++) {
      CS1->data[ixstart] += CS1->data[ixstart - 1];
    }
  }

  emxInit_real_T1(&b_xc, 1);
  n = xc->size[0];
  itmp = b_xc->size[0];
  b_xc->size[0] = y->size[1];
  emxEnsureCapacity_real_T1(b_xc, itmp);
  ixstart = y->size[1];
  for (itmp = 0; itmp < ixstart; itmp++) {
    b_xc->data[itmp] = (double)n - 2.0 * y->data[y->size[0] * itmp];
  }

  emxFree_real_T(&y);
  emxInit_real_T1(&r8, 1);
  repmat(b_xc, r8);
  itmp = b_xc->size[0];
  b_xc->size[0] = b_y->size[1];
  emxEnsureCapacity_real_T1(b_xc, itmp);
  ixstart = b_y->size[1];
  for (itmp = 0; itmp < ixstart; itmp++) {
    b_xc->data[itmp] = b_y->data[b_y->size[0] * itmp];
  }

  emxFree_real_T(&b_y);
  emxInit_real_T1(&r9, 1);
  repmat(b_xc, r9);
  itmp = b_xc->size[0];
  b_xc->size[0] = r8->size[0];
  emxEnsureCapacity_real_T1(b_xc, itmp);
  ixstart = r8->size[0];
  for (itmp = 0; itmp < ixstart; itmp++) {
    b_xc->data[itmp] = (r8->data[itmp] + CS1->data[itmp]) + r9->data[itmp] *
      sx2->data[itmp];
  }

  emxFree_real_T(&r9);
  emxFree_real_T(&r8);
  emxFree_real_T(&CS1);
  rdivide(b_xc, (double)xc->size[0], sx2);
  ixstart = 1;
  n = sx2->size[0];
  mtmp = sx2->data[0];
  itmp = 0;
  emxFree_real_T(&b_xc);
  emxFree_real_T(&xc);
  if (sx2->size[0] > 1) {
    if (rtIsNaN(sx2->data[0])) {
      ix = 2;
      exitg1 = false;
      while ((!exitg1) && (ix <= n)) {
        ixstart = ix;
        if (!rtIsNaN(sx2->data[ix - 1])) {
          mtmp = sx2->data[ix - 1];
          itmp = ix - 1;
          exitg1 = true;
        } else {
          ix++;
        }
      }
    }

    if (ixstart < sx2->size[0]) {
      while (ixstart + 1 <= n) {
        if (sx2->data[ixstart] < mtmp) {
          mtmp = sx2->data[ixstart];
          itmp = ixstart;
        }

        ixstart++;
      }
    }
  }

  emxFree_real_T(&sx2);
  thr = sx->data[itmp];
  emxFree_real_T(&sx);
  return thr;
}

//
// File trailer for thselect.cpp
//
// [EOF]
//
