//
// File: FekgClus.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "FekgClus_emxutil.h"
#include "sort1.h"
#include "kmeans.h"
#include "nullAssignment.h"
#include "findpeaks.h"
#include "wden.h"
#include "waverec.h"
#include "wextend.h"
#include "wavedec.h"

// Function Definitions

//
// clear
//  cd 'C:\Users\Anggara\Documents\Skripshit\program\data1'
//  load('fekgShort.mat', 'x', 'abd1')
// Arguments    : const emxArray_real_T *x
//                const emxArray_real_T *abd1
//                emxArray_real_T *xfin
//                emxArray_real_T *abd
//                emxArray_real_T *abd_den
//                emxArray_real_T *abd_peak1
//                emxArray_real_T *abd_peak2
// Return Type  : void
//
void FekgClus(const emxArray_real_T *x, const emxArray_real_T *abd1,
              emxArray_real_T *xfin, emxArray_real_T *abd, emxArray_real_T
              *abd_den, emxArray_real_T *abd_peak1, emxArray_real_T *abd_peak2)
{
  int i0;
  int i;
  emxArray_real_T *a;
  double l[12];
  emxArray_real_T *b_a;
  emxArray_real_T *CA;
  emxArray_real_T *b_abd_den;
  emxArray_real_T *j;
  int n;
  emxArray_real_T *abd_peak;
  emxArray_real_T *abd_valley;
  emxArray_real_T *b_abd_peak;
  emxArray_real_T *abd_clus;
  double Cent[3];
  int iidx[3];
  int idx;
  emxArray_int32_T *ii;
  int varargin_1;
  emxArray_int32_T *r0;
  emxArray_int32_T *r1;
  int m;
  emxArray_int32_T *r2;
  emxArray_boolean_T *b_x;
  emxArray_boolean_T *c_x;
  emxArray_int32_T *b_ii;
  emxArray_int32_T *r3;
  double c_abd_den;
  emxArray_int32_T *r4;
  boolean_T exitg1;
  i0 = xfin->size[0] * xfin->size[1];
  xfin->size[0] = 1;
  xfin->size[1] = x->size[1];
  emxEnsureCapacity_real_T(xfin, i0);
  i = x->size[0] * x->size[1];
  for (i0 = 0; i0 < i; i0++) {
    xfin->data[i0] = x->data[i0];
  }

  i0 = abd->size[0] * abd->size[1];
  abd->size[0] = 1;
  abd->size[1] = abd1->size[1];
  emxEnsureCapacity_real_T(abd, i0);
  i = abd1->size[0] * abd1->size[1];
  for (i0 = 0; i0 < i; i0++) {
    abd->data[i0] = abd1->data[i0];
  }

  emxInit_real_T(&a, 2);

  //  figure
  //  plot(x,abd);
  wavedec(abd1, a, l);
  if (1.0 > l[0]) {
    i = 0;
  } else {
    i = (int)l[0];
  }

  emxInit_real_T(&b_a, 2);
  i0 = b_a->size[0] * b_a->size[1];
  b_a->size[0] = 1;
  b_a->size[1] = i;
  emxEnsureCapacity_real_T(b_a, i0);
  for (i0 = 0; i0 < i; i0++) {
    b_a->data[b_a->size[0] * i0] = a->data[i0];
  }

  emxInit_real_T(&CA, 2);
  wextend(b_a, (double)a->size[1] - l[0], CA);
  waverec(CA, l, a);

  //  figure
  //  plot(x,a)
  i0 = b_a->size[0] * b_a->size[1];
  b_a->size[0] = 1;
  b_a->size[1] = abd1->size[1];
  emxEnsureCapacity_real_T(b_a, i0);
  i = abd1->size[0] * abd1->size[1];
  for (i0 = 0; i0 < i; i0++) {
    b_a->data[i0] = abd1->data[i0] - a->data[i0];
  }

  wden(b_a, abd_den);

  //  figure
  //  plot(x,abd_den)
  findpeaks(abd_den, a, b_a);
  i0 = a->size[0] * a->size[1];
  a->size[0] = 1;
  a->size[1] = b_a->size[1];
  emxEnsureCapacity_real_T(a, i0);
  i = b_a->size[0] * b_a->size[1];
  for (i0 = 0; i0 < i; i0++) {
    a->data[i0] = b_a->data[i0];
  }

  emxInit_real_T(&b_abd_den, 2);
  i0 = b_abd_den->size[0] * b_abd_den->size[1];
  b_abd_den->size[0] = 1;
  b_abd_den->size[1] = abd_den->size[1];
  emxEnsureCapacity_real_T(b_abd_den, i0);
  i = abd_den->size[0] * abd_den->size[1];
  for (i0 = 0; i0 < i; i0++) {
    b_abd_den->data[i0] = -abd_den->data[i0];
  }

  emxInit_real_T(&j, 2);
  findpeaks(b_abd_den, CA, j);
  emxFree_real_T(&b_abd_den);
  emxFree_real_T(&CA);
  if (b_a->data[0] > j->data[0]) {
    i = j->size[1];
    for (n = 0; n <= i - 2; n++) {
      j->data[n] = j->data[n + 1];
    }

    i0 = j->size[1];
    nullAssignment(j, i0);
  }

  if (b_a->size[1] > j->size[1]) {
    nullAssignment(a, b_a->size[1]);
  }

  emxFree_real_T(&b_a);
  emxInit_real_T1(&abd_peak, 1);
  i0 = abd_peak->size[0];
  abd_peak->size[0] = a->size[1];
  emxEnsureCapacity_real_T1(abd_peak, i0);
  i = a->size[1];
  for (i0 = 0; i0 < i; i0++) {
    abd_peak->data[i0] = abd_den->data[(int)a->data[a->size[0] * i0] - 1];
  }

  emxInit_real_T1(&abd_valley, 1);
  i0 = abd_valley->size[0];
  abd_valley->size[0] = j->size[1];
  emxEnsureCapacity_real_T1(abd_valley, i0);
  i = j->size[1];
  for (i0 = 0; i0 < i; i0++) {
    abd_valley->data[i0] = abd_den->data[(int)j->data[j->size[0] * i0] - 1];
  }

  emxInit_real_T1(&b_abd_peak, 1);

  //  plot(abd_amp, '*')
  i0 = b_abd_peak->size[0];
  b_abd_peak->size[0] = abd_peak->size[0];
  emxEnsureCapacity_real_T1(b_abd_peak, i0);
  i = abd_peak->size[0];
  for (i0 = 0; i0 < i; i0++) {
    b_abd_peak->data[i0] = abd_peak->data[i0] - abd_valley->data[i0];
  }

  emxInit_real_T1(&abd_clus, 1);
  kmeans(b_abd_peak, abd_clus, Cent);
  b_sort(Cent, iidx);
  emxFree_real_T(&b_abd_peak);
  for (i = 0; i < 3; i++) {
    Cent[i] = iidx[i];
  }

  idx = abd_clus->size[0] - 1;
  n = 0;
  for (i = 0; i <= idx; i++) {
    if (abd_clus->data[i] == Cent[2]) {
      n++;
    }
  }

  emxInit_int32_T(&ii, 1);
  i0 = ii->size[0];
  ii->size[0] = n;
  emxEnsureCapacity_int32_T(ii, i0);
  n = 0;
  for (i = 0; i <= idx; i++) {
    if (abd_clus->data[i] == Cent[2]) {
      ii->data[n] = i + 1;
      n++;
    }
  }

  varargin_1 = ii->size[0];
  i0 = abd_peak1->size[0];
  abd_peak1->size[0] = varargin_1;
  emxEnsureCapacity_real_T1(abd_peak1, i0);
  for (i0 = 0; i0 < varargin_1; i0++) {
    abd_peak1->data[i0] = 0.0;
  }

  idx = abd_clus->size[0] - 1;
  n = 0;
  for (i = 0; i <= idx; i++) {
    if (abd_clus->data[i] == Cent[1]) {
      n++;
    }
  }

  emxInit_int32_T(&r0, 1);
  i0 = r0->size[0];
  r0->size[0] = n;
  emxEnsureCapacity_int32_T(r0, i0);
  n = 0;
  for (i = 0; i <= idx; i++) {
    if (abd_clus->data[i] == Cent[1]) {
      r0->data[n] = i + 1;
      n++;
    }
  }

  varargin_1 = r0->size[0];
  i0 = abd_peak2->size[0];
  abd_peak2->size[0] = varargin_1;
  emxEnsureCapacity_real_T1(abd_peak2, i0);
  emxFree_int32_T(&r0);
  for (i0 = 0; i0 < varargin_1; i0++) {
    abd_peak2->data[i0] = 0.0;
  }

  idx = abd_clus->size[0] - 1;
  n = 0;
  for (i = 0; i <= idx; i++) {
    if (abd_clus->data[i] == Cent[2]) {
      n++;
    }
  }

  emxInit_int32_T(&r1, 1);
  i0 = r1->size[0];
  r1->size[0] = n;
  emxEnsureCapacity_int32_T(r1, i0);
  n = 0;
  for (i = 0; i <= idx; i++) {
    if (abd_clus->data[i] == Cent[2]) {
      r1->data[n] = i + 1;
      n++;
    }
  }

  varargin_1 = r1->size[0];
  m = 0;
  emxFree_int32_T(&r1);
  emxInit_int32_T(&r2, 1);
  emxInit_boolean_T(&b_x, 1);
  emxInit_boolean_T1(&c_x, 2);
  emxInit_int32_T1(&b_ii, 2);
  while (m <= varargin_1 - 1) {
    idx = abd_clus->size[0] - 1;
    n = 0;
    for (i = 0; i <= idx; i++) {
      if (abd_clus->data[i] == Cent[2]) {
        n++;
      }
    }

    i0 = r2->size[0];
    r2->size[0] = n;
    emxEnsureCapacity_int32_T(r2, i0);
    n = 0;
    for (i = 0; i <= idx; i++) {
      if (abd_clus->data[i] == Cent[2]) {
        r2->data[n] = i + 1;
        n++;
      }
    }

    c_abd_den = abd_den->data[(int)a->data[a->size[0] * (r2->data[m] - 1)] - 1]
      - abd_den->data[(int)j->data[j->size[0] * (r2->data[m] - 1)] - 1];
    i0 = b_x->size[0];
    b_x->size[0] = abd_peak->size[0];
    emxEnsureCapacity_boolean_T(b_x, i0);
    i = abd_peak->size[0];
    for (i0 = 0; i0 < i; i0++) {
      b_x->data[i0] = (abd_peak->data[i0] - abd_valley->data[i0] == c_abd_den);
    }

    i = b_x->size[0];
    idx = 0;
    i0 = ii->size[0];
    ii->size[0] = b_x->size[0];
    emxEnsureCapacity_int32_T(ii, i0);
    n = 1;
    exitg1 = false;
    while ((!exitg1) && (n <= i)) {
      if (b_x->data[n - 1]) {
        idx++;
        ii->data[idx - 1] = n;
        if (idx >= i) {
          exitg1 = true;
        } else {
          n++;
        }
      } else {
        n++;
      }
    }

    if (b_x->size[0] == 1) {
      if (idx == 0) {
        i0 = ii->size[0];
        ii->size[0] = 0;
        emxEnsureCapacity_int32_T(ii, i0);
      }
    } else {
      i0 = ii->size[0];
      if (1 > idx) {
        ii->size[0] = 0;
      } else {
        ii->size[0] = idx;
      }

      emxEnsureCapacity_int32_T(ii, i0);
    }

    abd_peak1->data[m] = ii->data[0];
    abd_peak1->data[m] = abd_den->data[(int)a->data[a->size[0] * ((int)
      abd_peak1->data[m] - 1)] - 1];
    i0 = c_x->size[0] * c_x->size[1];
    c_x->size[0] = 1;
    c_x->size[1] = abd_den->size[1];
    emxEnsureCapacity_boolean_T1(c_x, i0);
    c_abd_den = abd_peak1->data[m];
    i = abd_den->size[0] * abd_den->size[1];
    for (i0 = 0; i0 < i; i0++) {
      c_x->data[i0] = (abd_den->data[i0] == c_abd_den);
    }

    i = c_x->size[1];
    idx = 0;
    i0 = b_ii->size[0] * b_ii->size[1];
    b_ii->size[0] = 1;
    b_ii->size[1] = c_x->size[1];
    emxEnsureCapacity_int32_T1(b_ii, i0);
    n = 1;
    exitg1 = false;
    while ((!exitg1) && (n <= i)) {
      if (c_x->data[n - 1]) {
        idx++;
        b_ii->data[idx - 1] = n;
        if (idx >= i) {
          exitg1 = true;
        } else {
          n++;
        }
      } else {
        n++;
      }
    }

    if (c_x->size[1] == 1) {
      if (idx == 0) {
        i0 = b_ii->size[0] * b_ii->size[1];
        b_ii->size[0] = 1;
        b_ii->size[1] = 0;
        emxEnsureCapacity_int32_T1(b_ii, i0);
      }
    } else {
      i0 = b_ii->size[0] * b_ii->size[1];
      if (1 > idx) {
        b_ii->size[1] = 0;
      } else {
        b_ii->size[1] = idx;
      }

      emxEnsureCapacity_int32_T1(b_ii, i0);
    }

    abd_peak1->data[m] = b_ii->data[0];
    m++;
  }

  emxFree_int32_T(&r2);
  idx = abd_clus->size[0] - 1;
  n = 0;
  for (i = 0; i <= idx; i++) {
    if (abd_clus->data[i] == Cent[1]) {
      n++;
    }
  }

  emxInit_int32_T(&r3, 1);
  i0 = r3->size[0];
  r3->size[0] = n;
  emxEnsureCapacity_int32_T(r3, i0);
  n = 0;
  for (i = 0; i <= idx; i++) {
    if (abd_clus->data[i] == Cent[1]) {
      r3->data[n] = i + 1;
      n++;
    }
  }

  varargin_1 = r3->size[0];
  m = 0;
  emxFree_int32_T(&r3);
  emxInit_int32_T(&r4, 1);
  while (m <= varargin_1 - 1) {
    idx = abd_clus->size[0] - 1;
    n = 0;
    for (i = 0; i <= idx; i++) {
      if (abd_clus->data[i] == Cent[1]) {
        n++;
      }
    }

    i0 = r4->size[0];
    r4->size[0] = n;
    emxEnsureCapacity_int32_T(r4, i0);
    n = 0;
    for (i = 0; i <= idx; i++) {
      if (abd_clus->data[i] == Cent[1]) {
        r4->data[n] = i + 1;
        n++;
      }
    }

    c_abd_den = abd_den->data[(int)a->data[a->size[0] * (r4->data[m] - 1)] - 1]
      - abd_den->data[(int)j->data[j->size[0] * (r4->data[m] - 1)] - 1];
    i0 = b_x->size[0];
    b_x->size[0] = abd_peak->size[0];
    emxEnsureCapacity_boolean_T(b_x, i0);
    i = abd_peak->size[0];
    for (i0 = 0; i0 < i; i0++) {
      b_x->data[i0] = (abd_peak->data[i0] - abd_valley->data[i0] == c_abd_den);
    }

    i = b_x->size[0];
    idx = 0;
    i0 = ii->size[0];
    ii->size[0] = b_x->size[0];
    emxEnsureCapacity_int32_T(ii, i0);
    n = 1;
    exitg1 = false;
    while ((!exitg1) && (n <= i)) {
      if (b_x->data[n - 1]) {
        idx++;
        ii->data[idx - 1] = n;
        if (idx >= i) {
          exitg1 = true;
        } else {
          n++;
        }
      } else {
        n++;
      }
    }

    if (b_x->size[0] == 1) {
      if (idx == 0) {
        i0 = ii->size[0];
        ii->size[0] = 0;
        emxEnsureCapacity_int32_T(ii, i0);
      }
    } else {
      i0 = ii->size[0];
      if (1 > idx) {
        ii->size[0] = 0;
      } else {
        ii->size[0] = idx;
      }

      emxEnsureCapacity_int32_T(ii, i0);
    }

    abd_peak2->data[m] = ii->data[0];
    abd_peak2->data[m] = abd_den->data[(int)a->data[a->size[0] * ((int)
      abd_peak2->data[m] - 1)] - 1];
    i0 = c_x->size[0] * c_x->size[1];
    c_x->size[0] = 1;
    c_x->size[1] = abd_den->size[1];
    emxEnsureCapacity_boolean_T1(c_x, i0);
    c_abd_den = abd_peak2->data[m];
    i = abd_den->size[0] * abd_den->size[1];
    for (i0 = 0; i0 < i; i0++) {
      c_x->data[i0] = (abd_den->data[i0] == c_abd_den);
    }

    i = c_x->size[1];
    idx = 0;
    i0 = b_ii->size[0] * b_ii->size[1];
    b_ii->size[0] = 1;
    b_ii->size[1] = c_x->size[1];
    emxEnsureCapacity_int32_T1(b_ii, i0);
    n = 1;
    exitg1 = false;
    while ((!exitg1) && (n <= i)) {
      if (c_x->data[n - 1]) {
        idx++;
        b_ii->data[idx - 1] = n;
        if (idx >= i) {
          exitg1 = true;
        } else {
          n++;
        }
      } else {
        n++;
      }
    }

    if (c_x->size[1] == 1) {
      if (idx == 0) {
        i0 = b_ii->size[0] * b_ii->size[1];
        b_ii->size[0] = 1;
        b_ii->size[1] = 0;
        emxEnsureCapacity_int32_T1(b_ii, i0);
      }
    } else {
      i0 = b_ii->size[0] * b_ii->size[1];
      if (1 > idx) {
        b_ii->size[1] = 0;
      } else {
        b_ii->size[1] = idx;
      }

      emxEnsureCapacity_int32_T1(b_ii, i0);
    }

    abd_peak2->data[m] = b_ii->data[0];
    m++;
  }

  emxFree_int32_T(&b_ii);
  emxFree_boolean_T(&c_x);
  emxFree_int32_T(&ii);
  emxFree_boolean_T(&b_x);
  emxFree_int32_T(&r4);
  emxFree_real_T(&abd_clus);
  emxFree_real_T(&abd_valley);
  emxFree_real_T(&abd_peak);
  emxFree_real_T(&j);
  emxFree_real_T(&a);

  //  figure
  //  plot(x,abd_den,'k',x(abd_peak1),abd_den(abd_peak1),'bo')
  //  hold on
  //  plot(x(abd_peak2),abd_den(abd_peak2),'ro')
  //  hold off
}

//
// File trailer for FekgClus.cpp
//
// [EOF]
//
