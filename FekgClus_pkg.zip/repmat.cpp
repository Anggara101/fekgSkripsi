//
// File: repmat.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "repmat.h"
#include "FekgClus_emxutil.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *a
//                emxArray_real_T *b
// Return Type  : void
//
void repmat(const emxArray_real_T *a, emxArray_real_T *b)
{
  int outsize_idx_0;
  int i6;
  outsize_idx_0 = a->size[0];
  i6 = b->size[0];
  b->size[0] = outsize_idx_0;
  emxEnsureCapacity_real_T1(b, i6);
  if ((!(a->size[0] == 0)) && (!(outsize_idx_0 == 0))) {
    for (outsize_idx_0 = 0; outsize_idx_0 + 1 <= a->size[0]; outsize_idx_0++) {
      b->data[outsize_idx_0] = a->data[outsize_idx_0];
    }
  }
}

//
// File trailer for repmat.cpp
//
// [EOF]
//
