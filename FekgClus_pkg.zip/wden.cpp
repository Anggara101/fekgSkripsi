//
// File: wden.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "wden.h"
#include "FekgClus_emxutil.h"
#include "idwt.h"
#include "thselect.h"
#include "wnoisest.h"
#include "dwt.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *in1
//                emxArray_real_T *xd
// Return Type  : void
//
void wden(const emxArray_real_T *in1, emxArray_real_T *xd)
{
  emxArray_real_T *c;
  int i5;
  emxArray_real_T *xv;
  double l[7];
  int tmp;
  emxArray_real_T *d;
  emxArray_real_T *b_xv;
  double s[5];
  int k;
  double thrs[5];
  int n;
  int first[5];
  int last[5];
  emxArray_int32_T *flk;
  emxArray_real_T *acol;
  int b_k;
  emxArray_real_T *c_xv;
  double thr;
  emxArray_real_T *b_acol;
  emxArray_int32_T *r7;
  boolean_T exitg1;
  emxInit_real_T(&c, 2);
  i5 = c->size[0] * c->size[1];
  c->size[0] = 1;
  c->size[1] = 0;
  emxEnsureCapacity_real_T(c, i5);
  for (i5 = 0; i5 < 7; i5++) {
    l[i5] = 0.0;
  }

  emxInit_real_T(&xv, 2);
  tmp = in1->size[1];
  i5 = xv->size[0] * xv->size[1];
  xv->size[0] = 1;
  xv->size[1] = tmp;
  emxEnsureCapacity_real_T(xv, i5);
  for (i5 = 0; i5 < tmp; i5++) {
    xv->data[xv->size[0] * i5] = in1->data[i5];
  }

  emxInit_real_T(&d, 2);
  emxInit_real_T(&b_xv, 2);
  if (in1->size[1] != 0) {
    l[6] = in1->size[1];
    for (k = 0; k < 5; k++) {
      i5 = b_xv->size[0] * b_xv->size[1];
      b_xv->size[0] = 1;
      b_xv->size[1] = xv->size[1];
      emxEnsureCapacity_real_T(b_xv, i5);
      n = xv->size[0] * xv->size[1];
      for (i5 = 0; i5 < n; i5++) {
        b_xv->data[i5] = xv->data[i5];
      }

      dwt(b_xv, xv, d);
      i5 = b_xv->size[0] * b_xv->size[1];
      b_xv->size[0] = 1;
      b_xv->size[1] = d->size[1] + c->size[1];
      emxEnsureCapacity_real_T(b_xv, i5);
      n = d->size[1];
      for (i5 = 0; i5 < n; i5++) {
        b_xv->data[b_xv->size[0] * i5] = d->data[d->size[0] * i5];
      }

      n = c->size[1];
      for (i5 = 0; i5 < n; i5++) {
        b_xv->data[b_xv->size[0] * (i5 + d->size[1])] = c->data[c->size[0] * i5];
      }

      i5 = c->size[0] * c->size[1];
      c->size[0] = 1;
      c->size[1] = b_xv->size[1];
      emxEnsureCapacity_real_T(c, i5);
      n = b_xv->size[1];
      for (i5 = 0; i5 < n; i5++) {
        c->data[c->size[0] * i5] = b_xv->data[b_xv->size[0] * i5];
      }

      l[5 - k] = d->size[1];
    }

    i5 = b_xv->size[0] * b_xv->size[1];
    b_xv->size[0] = 1;
    b_xv->size[1] = xv->size[1] + c->size[1];
    emxEnsureCapacity_real_T(b_xv, i5);
    n = xv->size[1];
    for (i5 = 0; i5 < n; i5++) {
      b_xv->data[b_xv->size[0] * i5] = xv->data[xv->size[0] * i5];
    }

    n = c->size[1];
    for (i5 = 0; i5 < n; i5++) {
      b_xv->data[b_xv->size[0] * (i5 + xv->size[1])] = c->data[c->size[0] * i5];
    }

    i5 = c->size[0] * c->size[1];
    c->size[0] = 1;
    c->size[1] = b_xv->size[1];
    emxEnsureCapacity_real_T(c, i5);
    n = b_xv->size[1];
    for (i5 = 0; i5 < n; i5++) {
      c->data[c->size[0] * i5] = b_xv->data[b_xv->size[0] * i5];
    }

    l[0] = xv->size[1];
  }

  wnoisest(c, l, s);
  for (i5 = 0; i5 < 5; i5++) {
    thrs[i5] = (unsigned int)l[i5];
  }

  for (k = 0; k < 4; k++) {
    thrs[k + 1] += thrs[k];
  }

  for (i5 = 0; i5 < 5; i5++) {
    first[i5] = (int)thrs[i5] + 1;
  }

  for (k = 0; k < 2; k++) {
    tmp = first[k];
    first[k] = first[4 - k];
    first[4 - k] = tmp;
  }

  for (i5 = 0; i5 < 5; i5++) {
    last[i5] = ((int)(unsigned int)l[5 - i5] + first[i5]) - 1;
  }

  i5 = xv->size[0] * xv->size[1];
  xv->size[0] = 1;
  xv->size[1] = c->size[1];
  emxEnsureCapacity_real_T(xv, i5);
  n = c->size[0] * c->size[1];
  for (i5 = 0; i5 < n; i5++) {
    xv->data[i5] = c->data[i5];
  }

  emxInit_int32_T1(&flk, 2);
  for (k = 0; k < 5; k++) {
    if (last[k] < first[k]) {
      n = 0;
    } else {
      n = (last[k] - first[k]) + 1;
    }

    i5 = flk->size[0] * flk->size[1];
    flk->size[0] = 1;
    flk->size[1] = n;
    emxEnsureCapacity_int32_T1(flk, i5);
    if (n > 0) {
      flk->data[0] = first[k];
      tmp = first[k];
      for (b_k = 2; b_k <= n; b_k++) {
        tmp++;
        flk->data[b_k - 1] = tmp;
      }
    }

    tmp = 1;
    n = flk->size[1];
    thr = c->data[flk->data[0] - 1];
    if (flk->size[1] > 1) {
      if (rtIsNaN(thr)) {
        b_k = 2;
        exitg1 = false;
        while ((!exitg1) && (b_k <= n)) {
          tmp = b_k;
          if (!rtIsNaN(c->data[flk->data[flk->size[0] * (b_k - 1)] - 1])) {
            thr = c->data[flk->data[flk->size[0] * (b_k - 1)] - 1];
            exitg1 = true;
          } else {
            b_k++;
          }
        }
      }

      if (tmp < flk->size[1]) {
        while (tmp + 1 <= n) {
          if (c->data[flk->data[flk->size[0] * tmp] - 1] > thr) {
            thr = c->data[flk->data[flk->size[0] * tmp] - 1];
          }

          tmp++;
        }
      }
    }

    if (s[k] < 1.4901161193847656E-8 * thr) {
      thr = 0.0;
    } else {
      i5 = b_xv->size[0] * b_xv->size[1];
      b_xv->size[0] = 1;
      b_xv->size[1] = flk->size[1];
      emxEnsureCapacity_real_T(b_xv, i5);
      n = flk->size[0] * flk->size[1];
      for (i5 = 0; i5 < n; i5++) {
        b_xv->data[i5] = c->data[flk->data[i5] - 1] / s[k];
      }

      thr = thselect(b_xv);
    }

    thrs[k] = thr * s[k];
    i5 = d->size[0] * d->size[1];
    d->size[0] = 1;
    d->size[1] = flk->size[1];
    emxEnsureCapacity_real_T(d, i5);
    n = flk->size[0] * flk->size[1];
    for (i5 = 0; i5 < n; i5++) {
      d->data[i5] = c->data[flk->data[i5] - 1];
    }

    i5 = flk->size[1];
    for (b_k = 0; b_k < i5; b_k++) {
      d->data[b_k] *= (double)(std::abs(d->data[b_k]) > thrs[k]);
    }

    n = d->size[0] * d->size[1];
    for (i5 = 0; i5 < n; i5++) {
      xv->data[flk->data[i5] - 1] = d->data[i5];
    }
  }

  emxFree_real_T(&b_xv);
  emxFree_real_T(&d);
  emxFree_real_T(&c);
  emxFree_int32_T(&flk);
  emxInit_real_T1(&acol, 1);
  i5 = acol->size[0];
  acol->size[0] = (int)(unsigned int)l[0];
  emxEnsureCapacity_real_T1(acol, i5);
  for (k = 0; k < (int)(unsigned int)l[0]; k++) {
    acol->data[k] = xv->data[k];
  }

  emxInit_real_T1(&c_xv, 1);
  emxInit_real_T1(&b_acol, 1);
  emxInit_int32_T(&r7, 1);
  for (k = 4; k >= 0; k--) {
    for (i5 = 0; i5 < 5; i5++) {
      first[i5] = 0;
      last[i5] = 0;
    }

    first[4] = (int)(unsigned int)l[0] + 1;
    last[4] = (int)(unsigned int)l[0] + (int)(unsigned int)l[1];
    for (tmp = 3; tmp >= 0; tmp--) {
      first[tmp] = first[tmp + 1] + (int)(unsigned int)l[4 - tmp];
      last[tmp] = (first[tmp] + (int)(unsigned int)l[5 - tmp]) - 1;
    }

    if (first[k] > last[k]) {
      i5 = 1;
      tmp = 0;
    } else {
      i5 = first[k];
      tmp = last[k];
    }

    b_k = r7->size[0];
    r7->size[0] = (tmp - i5) + 1;
    emxEnsureCapacity_int32_T(r7, b_k);
    n = tmp - i5;
    for (b_k = 0; b_k <= n; b_k++) {
      r7->data[b_k] = i5 + b_k;
    }

    b_k = c_xv->size[0];
    c_xv->size[0] = (tmp - i5) + 1;
    emxEnsureCapacity_real_T1(c_xv, b_k);
    n = tmp - i5;
    for (i5 = 0; i5 <= n; i5++) {
      c_xv->data[i5] = xv->data[r7->data[i5] - 1];
    }

    i5 = b_acol->size[0];
    b_acol->size[0] = acol->size[0];
    emxEnsureCapacity_real_T1(b_acol, i5);
    n = acol->size[0];
    for (i5 = 0; i5 < n; i5++) {
      b_acol->data[i5] = acol->data[i5];
    }

    idwt(b_acol, c_xv, (double)(unsigned int)l[6 - k], acol);
  }

  emxFree_int32_T(&r7);
  emxFree_real_T(&b_acol);
  emxFree_real_T(&c_xv);
  emxFree_real_T(&xv);
  i5 = xd->size[0] * xd->size[1];
  xd->size[0] = 1;
  xd->size[1] = acol->size[0];
  emxEnsureCapacity_real_T(xd, i5);
  n = acol->size[0];
  for (i5 = 0; i5 < n; i5++) {
    xd->data[xd->size[0] * i5] = acol->data[i5];
  }

  emxFree_real_T(&acol);
}

//
// File trailer for wden.cpp
//
// [EOF]
//
