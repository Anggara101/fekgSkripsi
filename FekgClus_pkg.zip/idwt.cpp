//
// File: idwt.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "idwt.h"
#include "FekgClus_emxutil.h"
#include "upsconv1.h"
#include "wkeep1.h"
#include "convn_kernel.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *a
//                const emxArray_real_T *d
//                double varargin_3
//                emxArray_real_T *x
// Return Type  : void
//
void idwt(const emxArray_real_T *a, const emxArray_real_T *d, double varargin_3,
          emxArray_real_T *x)
{
  boolean_T NONEMPTYD;
  emxArray_real_T *y;
  int cEnd1;
  int b_y;
  emxArray_real_T *b_y1;
  int c_size_idx_0;
  double c_data[14];
  int iC;
  static const double B[8] = { 0.0322231006040427, -0.012603967262037833,
    -0.099219543576847216, 0.29785779560527736, 0.80373875180591614,
    0.49761866763201545, -0.02963552764599851, -0.075765714789273325 };

  int iB;
  int lastRowA;
  int aidx;
  int cidx;
  int r;
  NONEMPTYD = !(d->size[0] == 0);
  if (!(a->size[0] == 0)) {
    emxInit_real_T1(&y, 1);
    b_y = (a->size[0] << 1) - 2;
    cEnd1 = y->size[0];
    y->size[0] = b_y + 1;
    emxEnsureCapacity_real_T1(y, cEnd1);
    for (cEnd1 = 0; cEnd1 <= b_y; cEnd1++) {
      y->data[cEnd1] = 0.0;
    }

    for (b_y = 1; b_y <= a->size[0]; b_y++) {
      y->data[(b_y << 1) - 2] = a->data[b_y - 1];
    }

    emxInit_real_T1(&b_y1, 1);
    if (8 > y->size[0]) {
      c_size_idx_0 = y->size[0] + 7;
      b_y = y->size[0];
      if (0 <= b_y + 6) {
        memset(&c_data[0], 0, (unsigned int)((b_y + 7) * (int)sizeof(double)));
      }

      cEnd1 = y->size[0] + 6;
      iC = 0;
      iB = 0;
      for (b_y = 0; b_y < y->size[0]; b_y++) {
        if (b_y + 8 <= cEnd1) {
          lastRowA = 8;
        } else {
          lastRowA = (cEnd1 - b_y) + 1;
        }

        aidx = 0;
        cidx = iC;
        for (r = 1; r <= lastRowA; r++) {
          c_data[cidx] += y->data[iB] * B[aidx];
          aidx++;
          cidx++;
        }

        iB++;
        iC++;
      }

      cEnd1 = b_y1->size[0];
      b_y1->size[0] = c_size_idx_0;
      emxEnsureCapacity_real_T1(b_y1, cEnd1);
      for (cEnd1 = 0; cEnd1 < c_size_idx_0; cEnd1++) {
        b_y1->data[cEnd1] = c_data[cEnd1];
      }
    } else {
      cEnd1 = b_y1->size[0];
      b_y1->size[0] = y->size[0] + 7;
      emxEnsureCapacity_real_T1(b_y1, cEnd1);
      b_y = y->size[0];
      for (cEnd1 = 0; cEnd1 <= b_y + 6; cEnd1++) {
        b_y1->data[cEnd1] = 0.0;
      }

      eml_conv2(b_y1, y, B, 0, y->size[0] + 6);
    }

    wkeep1(b_y1, (int)varargin_3, x);
    emxFree_real_T(&b_y1);
    if (NONEMPTYD) {
      upsconv1(d, varargin_3, y);
      cEnd1 = x->size[0];
      emxEnsureCapacity_real_T1(x, cEnd1);
      b_y = x->size[0];
      for (cEnd1 = 0; cEnd1 < b_y; cEnd1++) {
        x->data[cEnd1] += y->data[cEnd1];
      }
    }

    emxFree_real_T(&y);
  } else if (NONEMPTYD) {
    upsconv1(d, varargin_3, x);
  } else {
    cEnd1 = x->size[0];
    x->size[0] = 0;
    emxEnsureCapacity_real_T1(x, cEnd1);
  }
}

//
// File trailer for idwt.cpp
//
// [EOF]
//
