//
// File: FekgClus.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//
#ifndef FEKGCLUS_H
#define FEKGCLUS_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "FekgClus_types.h"

// Function Declarations
extern void FekgClus(const emxArray_real_T *x, const emxArray_real_T *abd1,
                     emxArray_real_T *xfin, emxArray_real_T *abd,
                     emxArray_real_T *abd_den, emxArray_real_T *abd_peak1,
                     emxArray_real_T *abd_peak2);

#endif

//
// File trailer for FekgClus.h
//
// [EOF]
//
