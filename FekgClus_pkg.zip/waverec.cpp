//
// File: waverec.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "waverec.h"
#include "FekgClus_emxutil.h"
#include "idwt.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *c
//                const double l[12]
//                emxArray_real_T *x
// Return Type  : void
//
void waverec(const emxArray_real_T *c, const double l[12], emxArray_real_T *x)
{
  emxArray_real_T *acol;
  int i;
  emxArray_real_T *b_c;
  emxArray_real_T *b_acol;
  emxArray_int32_T *r6;
  int p;
  int first[10];
  int last[10];
  int loop_ub;
  int i3;
  int i4;
  emxInit_real_T1(&acol, 1);
  i = acol->size[0];
  acol->size[0] = (int)l[0];
  emxEnsureCapacity_real_T1(acol, i);
  for (i = 0; i < (int)l[0]; i++) {
    acol->data[i] = c->data[i];
  }

  emxInit_real_T1(&b_c, 1);
  emxInit_real_T1(&b_acol, 1);
  emxInit_int32_T(&r6, 1);
  for (p = 9; p >= 0; p--) {
    for (i = 0; i < 10; i++) {
      first[i] = 0;
      last[i] = 0;
    }

    first[9] = (int)l[0] + 1;
    last[9] = (int)l[0] + (int)l[1];
    for (i = 8; i >= 0; i--) {
      first[i] = first[i + 1] + (int)l[9 - i];
      last[i] = (first[i] + (int)l[10 - i]) - 1;
    }

    if (first[p] > last[p]) {
      i = 1;
      i3 = 0;
    } else {
      i = first[p];
      i3 = last[p];
    }

    i4 = r6->size[0];
    r6->size[0] = (i3 - i) + 1;
    emxEnsureCapacity_int32_T(r6, i4);
    loop_ub = i3 - i;
    for (i4 = 0; i4 <= loop_ub; i4++) {
      r6->data[i4] = i + i4;
    }

    i4 = b_c->size[0];
    b_c->size[0] = (i3 - i) + 1;
    emxEnsureCapacity_real_T1(b_c, i4);
    loop_ub = i3 - i;
    for (i = 0; i <= loop_ub; i++) {
      b_c->data[i] = c->data[r6->data[i] - 1];
    }

    i = b_acol->size[0];
    b_acol->size[0] = acol->size[0];
    emxEnsureCapacity_real_T1(b_acol, i);
    loop_ub = acol->size[0];
    for (i = 0; i < loop_ub; i++) {
      b_acol->data[i] = acol->data[i];
    }

    idwt(b_acol, b_c, l[11 - p], acol);
  }

  emxFree_int32_T(&r6);
  emxFree_real_T(&b_acol);
  emxFree_real_T(&b_c);
  i = x->size[0] * x->size[1];
  x->size[0] = 1;
  x->size[1] = acol->size[0];
  emxEnsureCapacity_real_T(x, i);
  loop_ub = acol->size[0];
  for (i = 0; i < loop_ub; i++) {
    x->data[x->size[0] * i] = acol->data[i];
  }

  emxFree_real_T(&acol);
}

//
// File trailer for waverec.cpp
//
// [EOF]
//
