//
// File: convn_kernel.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//

// Include Files
#include "rt_nonfinite.h"
#include "FekgClus.h"
#include "convn_kernel.h"

// Function Definitions

//
// Arguments    : emxArray_real_T *C
//                const emxArray_real_T *A
//                const double B[8]
//                int firstRowC
//                int lastRowC
// Return Type  : void
//
void eml_conv2(emxArray_real_T *C, const emxArray_real_T *A, const double B[8],
               int firstRowC, int lastRowC)
{
  int ma;
  int iC;
  int iB;
  int i;
  int firstRowA;
  int b_i;
  int a_length;
  int cidx;
  int r;
  ma = A->size[0];
  iC = 0;
  iB = 0;
  for (i = 0; i < 8; i++) {
    if (i < firstRowC) {
      firstRowA = 7 - i;
    } else {
      firstRowA = 0;
    }

    if (i + ma <= lastRowC) {
      b_i = ma;
    } else {
      b_i = (lastRowC - i) + 1;
    }

    a_length = b_i - firstRowA;
    cidx = iC;
    for (r = 1; r <= a_length; r++) {
      C->data[cidx] += B[iB] * A->data[firstRowA];
      firstRowA++;
      cidx++;
    }

    iB++;
    if (i >= firstRowC) {
      iC++;
    }
  }
}

//
// File trailer for convn_kernel.cpp
//
// [EOF]
//
