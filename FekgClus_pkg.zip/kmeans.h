//
// File: kmeans.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 07-Jan-2022 16:31:45
//
#ifndef KMEANS_H
#define KMEANS_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "FekgClus_types.h"

// Function Declarations
extern void kmeans(emxArray_real_T *X, emxArray_real_T *idxbest, double Cbest[3]);

#endif

//
// File trailer for kmeans.h
//
// [EOF]
//
