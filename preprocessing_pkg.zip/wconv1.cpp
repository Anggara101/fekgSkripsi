//
// File: wconv1.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//

// Include Files
#include "rt_nonfinite.h"
#include "preprocessing.h"
#include "wconv1.h"
#include "preprocessing_emxutil.h"
#include "convn_kernel.h"

// Function Definitions

//
// Arguments    : const double x_data[]
//                const int x_size[2]
//                double y_data[]
//                int y_size[2]
// Return Type  : void
//
void b_wconv1(const double x_data[], const int x_size[2], double y_data[], int
              y_size[2])
{
  int loop_ub;
  double a_data[5014];
  int a_size[1];
  double b_a_data[5014];
  emxArray_real_T *r2;
  int i5;
  emxArray_real_T c_a_data;
  static const double B[8] = { -0.0322231006040427, -0.012603967262037833,
    0.099219543576847216, 0.29785779560527736, -0.80373875180591614,
    0.49761866763201545, 0.02963552764599851, -0.075765714789273325 };

  loop_ub = x_size[1];
  if (0 <= loop_ub - 1) {
    memcpy(&a_data[0], &x_data[0], (unsigned int)(loop_ub * (int)sizeof(double)));
  }

  loop_ub = x_size[1];
  a_size[0] = x_size[1];
  if (0 <= loop_ub - 1) {
    memcpy(&b_a_data[0], &a_data[0], (unsigned int)(loop_ub * (int)sizeof(double)));
  }

  emxInit_real_T1(&r2, 1);
  i5 = r2->size[0];
  r2->size[0] = a_size[0] - 7;
  emxEnsureCapacity_real_T1(r2, i5);
  loop_ub = a_size[0];
  for (i5 = 0; i5 <= loop_ub - 8; i5++) {
    r2->data[i5] = 0.0;
  }

  c_a_data.data = (double *)&b_a_data;
  c_a_data.size = (int *)&a_size;
  c_a_data.allocatedSize = 5014;
  c_a_data.numDimensions = 1;
  c_a_data.canFreeData = false;
  eml_conv2(r2, &c_a_data, B, 7, a_size[0] - 1);
  y_size[0] = 1;
  y_size[1] = r2->size[0];
  loop_ub = r2->size[0];
  for (i5 = 0; i5 < loop_ub; i5++) {
    y_data[i5] = r2->data[i5];
  }

  emxFree_real_T(&r2);
}

//
// Arguments    : const double x_data[]
//                const int x_size[2]
//                double y_data[]
//                int y_size[2]
// Return Type  : void
//
void wconv1(const double x_data[], const int x_size[2], double y_data[], int
            y_size[2])
{
  int loop_ub;
  double a_data[5014];
  int a_size[1];
  double b_a_data[5014];
  emxArray_real_T *r1;
  int i4;
  emxArray_real_T c_a_data;
  static const double B[8] = { -0.075765714789273325, -0.02963552764599851,
    0.49761866763201545, 0.80373875180591614, 0.29785779560527736,
    -0.099219543576847216, -0.012603967262037833, 0.0322231006040427 };

  loop_ub = x_size[1];
  if (0 <= loop_ub - 1) {
    memcpy(&a_data[0], &x_data[0], (unsigned int)(loop_ub * (int)sizeof(double)));
  }

  loop_ub = x_size[1];
  a_size[0] = x_size[1];
  if (0 <= loop_ub - 1) {
    memcpy(&b_a_data[0], &a_data[0], (unsigned int)(loop_ub * (int)sizeof(double)));
  }

  emxInit_real_T1(&r1, 1);
  i4 = r1->size[0];
  r1->size[0] = a_size[0] - 7;
  emxEnsureCapacity_real_T1(r1, i4);
  loop_ub = a_size[0];
  for (i4 = 0; i4 <= loop_ub - 8; i4++) {
    r1->data[i4] = 0.0;
  }

  c_a_data.data = (double *)&b_a_data;
  c_a_data.size = (int *)&a_size;
  c_a_data.allocatedSize = 5014;
  c_a_data.numDimensions = 1;
  c_a_data.canFreeData = false;
  eml_conv2(r1, &c_a_data, B, 7, a_size[0] - 1);
  y_size[0] = 1;
  y_size[1] = r1->size[0];
  loop_ub = r1->size[0];
  for (i4 = 0; i4 < loop_ub; i4++) {
    y_data[i4] = r1->data[i4];
  }

  emxFree_real_T(&r1);
}

//
// File trailer for wconv1.cpp
//
// [EOF]
//
