//
// File: preprocessing_initialize.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//

// Include Files
#include "rt_nonfinite.h"
#include "preprocessing.h"
#include "preprocessing_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void preprocessing_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for preprocessing_initialize.cpp
//
// [EOF]
//
