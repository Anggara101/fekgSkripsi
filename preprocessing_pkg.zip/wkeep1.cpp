//
// File: wkeep1.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//

// Include Files
#include "rt_nonfinite.h"
#include "preprocessing.h"
#include "wkeep1.h"
#include "preprocessing_emxutil.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *x
//                int len
//                emxArray_real_T *y
// Return Type  : void
//
void wkeep1(const emxArray_real_T *x, int len, emxArray_real_T *y)
{
  int first;
  int d;
  int nxmm;
  first = 1;
  d = x->size[0];
  if (len < x->size[0]) {
    nxmm = x->size[0] - len;
    d = nxmm >> 1;
    first = 1 + d;
    d = x->size[0] - d;
    if ((nxmm & 1) != 0) {
      d--;
    }
  }

  if (first > d) {
    first = 0;
    d = 0;
  } else {
    first--;
  }

  nxmm = y->size[0];
  y->size[0] = d - first;
  emxEnsureCapacity_real_T1(y, nxmm);
  d -= first;
  for (nxmm = 0; nxmm < d; nxmm++) {
    y->data[nxmm] = x->data[first + nxmm];
  }
}

//
// File trailer for wkeep1.cpp
//
// [EOF]
//
