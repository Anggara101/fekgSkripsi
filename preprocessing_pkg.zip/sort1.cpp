//
// File: sort1.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//

// Include Files
#include "rt_nonfinite.h"
#include "preprocessing.h"
#include "sort1.h"
#include "preprocessing_emxutil.h"
#include "sortIdx.h"

// Function Definitions

//
// Arguments    : emxArray_real_T *x
// Return Type  : void
//
void sort(emxArray_real_T *x)
{
  emxArray_int32_T *idx;
  int ib;
  int m;
  int n;
  int b_n;
  int i;
  emxArray_int32_T *iwork;
  double x4[4];
  int idx4[4];
  emxArray_real_T *xwork;
  int nNaNs;
  int k;
  int wOffset;
  signed char perm[4];
  int nNonNaN;
  int i4;
  int nBlocks;
  int nPairs;
  int b_iwork[256];
  double b_xwork[256];
  int exitg1;
  emxInit_int32_T(&idx, 1);
  ib = x->size[0];
  m = idx->size[0];
  idx->size[0] = ib;
  emxEnsureCapacity_int32_T(idx, m);
  for (m = 0; m < ib; m++) {
    idx->data[m] = 0;
  }

  n = x->size[0];
  b_n = x->size[0];
  for (i = 0; i < 4; i++) {
    x4[i] = 0.0;
    idx4[i] = 0;
  }

  emxInit_int32_T(&iwork, 1);
  m = iwork->size[0];
  iwork->size[0] = ib;
  emxEnsureCapacity_int32_T(iwork, m);
  for (m = 0; m < ib; m++) {
    iwork->data[m] = 0;
  }

  emxInit_real_T1(&xwork, 1);
  i = x->size[0];
  m = xwork->size[0];
  xwork->size[0] = i;
  emxEnsureCapacity_real_T1(xwork, m);
  for (m = 0; m < i; m++) {
    xwork->data[m] = 0.0;
  }

  nNaNs = 1;
  ib = 0;
  for (k = 0; k + 1 <= b_n; k++) {
    if (rtIsNaN(x->data[k])) {
      idx->data[b_n - nNaNs] = k + 1;
      xwork->data[b_n - nNaNs] = x->data[k];
      nNaNs++;
    } else {
      ib++;
      idx4[ib - 1] = k + 1;
      x4[ib - 1] = x->data[k];
      if (ib == 4) {
        i = k - nNaNs;
        if (x4[0] <= x4[1]) {
          ib = 1;
          m = 2;
        } else {
          ib = 2;
          m = 1;
        }

        if (x4[2] <= x4[3]) {
          wOffset = 3;
          i4 = 4;
        } else {
          wOffset = 4;
          i4 = 3;
        }

        if (x4[ib - 1] <= x4[wOffset - 1]) {
          if (x4[m - 1] <= x4[wOffset - 1]) {
            perm[0] = (signed char)ib;
            perm[1] = (signed char)m;
            perm[2] = (signed char)wOffset;
            perm[3] = (signed char)i4;
          } else if (x4[m - 1] <= x4[i4 - 1]) {
            perm[0] = (signed char)ib;
            perm[1] = (signed char)wOffset;
            perm[2] = (signed char)m;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)ib;
            perm[1] = (signed char)wOffset;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)m;
          }
        } else if (x4[ib - 1] <= x4[i4 - 1]) {
          if (x4[m - 1] <= x4[i4 - 1]) {
            perm[0] = (signed char)wOffset;
            perm[1] = (signed char)ib;
            perm[2] = (signed char)m;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)wOffset;
            perm[1] = (signed char)ib;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)m;
          }
        } else {
          perm[0] = (signed char)wOffset;
          perm[1] = (signed char)i4;
          perm[2] = (signed char)ib;
          perm[3] = (signed char)m;
        }

        idx->data[i - 2] = idx4[perm[0] - 1];
        idx->data[i - 1] = idx4[perm[1] - 1];
        idx->data[i] = idx4[perm[2] - 1];
        idx->data[i + 1] = idx4[perm[3] - 1];
        x->data[i - 2] = x4[perm[0] - 1];
        x->data[i - 1] = x4[perm[1] - 1];
        x->data[i] = x4[perm[2] - 1];
        x->data[i + 1] = x4[perm[3] - 1];
        ib = 0;
      }
    }
  }

  wOffset = b_n - nNaNs;
  if (ib > 0) {
    for (i = 0; i < 4; i++) {
      perm[i] = 0;
    }

    if (ib == 1) {
      perm[0] = 1;
    } else if (ib == 2) {
      if (x4[0] <= x4[1]) {
        perm[0] = 1;
        perm[1] = 2;
      } else {
        perm[0] = 2;
        perm[1] = 1;
      }
    } else if (x4[0] <= x4[1]) {
      if (x4[1] <= x4[2]) {
        perm[0] = 1;
        perm[1] = 2;
        perm[2] = 3;
      } else if (x4[0] <= x4[2]) {
        perm[0] = 1;
        perm[1] = 3;
        perm[2] = 2;
      } else {
        perm[0] = 3;
        perm[1] = 1;
        perm[2] = 2;
      }
    } else if (x4[0] <= x4[2]) {
      perm[0] = 2;
      perm[1] = 1;
      perm[2] = 3;
    } else if (x4[1] <= x4[2]) {
      perm[0] = 2;
      perm[1] = 3;
      perm[2] = 1;
    } else {
      perm[0] = 3;
      perm[1] = 2;
      perm[2] = 1;
    }

    for (k = 1; k <= ib; k++) {
      idx->data[(wOffset - ib) + k] = idx4[perm[k - 1] - 1];
      x->data[(wOffset - ib) + k] = x4[perm[k - 1] - 1];
    }
  }

  m = ((nNaNs - 1) >> 1) + 1;
  for (k = 1; k < m; k++) {
    i = idx->data[wOffset + k];
    idx->data[wOffset + k] = idx->data[b_n - k];
    idx->data[b_n - k] = i;
    x->data[wOffset + k] = xwork->data[b_n - k];
    x->data[b_n - k] = xwork->data[wOffset + k];
  }

  if (((nNaNs - 1) & 1) != 0) {
    x->data[wOffset + m] = xwork->data[wOffset + m];
  }

  nNonNaN = (n - nNaNs) + 1;
  i = 2;
  if (nNonNaN > 1) {
    if (n >= 256) {
      nBlocks = nNonNaN >> 8;
      if (nBlocks > 0) {
        for (wOffset = 1; wOffset <= nBlocks; wOffset++) {
          i4 = ((wOffset - 1) << 8) - 1;
          for (nNaNs = 0; nNaNs < 6; nNaNs++) {
            b_n = 1 << (nNaNs + 2);
            n = b_n << 1;
            nPairs = 256 >> (nNaNs + 3);
            for (k = 1; k <= nPairs; k++) {
              ib = i4 + (k - 1) * n;
              for (i = 1; i <= n; i++) {
                b_iwork[i - 1] = idx->data[ib + i];
                b_xwork[i - 1] = x->data[ib + i];
              }

              m = 0;
              i = b_n;
              do {
                exitg1 = 0;
                ib++;
                if (b_xwork[m] <= b_xwork[i]) {
                  idx->data[ib] = b_iwork[m];
                  x->data[ib] = b_xwork[m];
                  if (m + 1 < b_n) {
                    m++;
                  } else {
                    exitg1 = 1;
                  }
                } else {
                  idx->data[ib] = b_iwork[i];
                  x->data[ib] = b_xwork[i];
                  if (i + 1 < n) {
                    i++;
                  } else {
                    i = ib - m;
                    while (m + 1 <= b_n) {
                      idx->data[(i + m) + 1] = b_iwork[m];
                      x->data[(i + m) + 1] = b_xwork[m];
                      m++;
                    }

                    exitg1 = 1;
                  }
                }
              } while (exitg1 == 0);
            }
          }
        }

        i = nBlocks << 8;
        ib = nNonNaN - i;
        if (ib > 0) {
          merge_block(idx, x, i, ib, 2, iwork, xwork);
        }

        i = 8;
      }
    }

    merge_block(idx, x, 0, nNonNaN, i, iwork, xwork);
  }

  emxFree_real_T(&xwork);
  emxFree_int32_T(&iwork);
  emxFree_int32_T(&idx);
}

//
// File trailer for sort1.cpp
//
// [EOF]
//
