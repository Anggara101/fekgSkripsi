//
// File: wextend.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//
#ifndef WEXTEND_H
#define WEXTEND_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "preprocessing_types.h"

// Function Declarations
extern void wextend(const double x_data[], const int x_size[2], double y_data[],
                    int y_size[2]);

#endif

//
// File trailer for wextend.h
//
// [EOF]
//
