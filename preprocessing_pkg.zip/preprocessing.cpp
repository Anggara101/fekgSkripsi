//
// File: preprocessing.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//

// Include Files
#include "rt_nonfinite.h"
#include "preprocessing.h"
#include "wden.h"
#include "preprocessing_emxutil.h"
#include "idwt.h"
#include "dwt.h"

// Function Definitions

//
// figure
//  plot(x,abd);
// Arguments    : const double abd_data[]
//                const int abd_size[2]
//                emxArray_real_T *abd_den
// Return Type  : void
//
void preprocessing(const double abd_data[], const int abd_size[2],
                   emxArray_real_T *abd_den)
{
  emxArray_real_T *c;
  int i0;
  int xv_size[2];
  short l[12];
  int loop_ub;
  static double xv_data[5000];
  emxArray_real_T *d;
  int i;
  emxArray_real_T *CA;
  double b_xv_data[2503];
  int b_xv_size[2];
  double d_data[2503];
  int d_size[2];
  int i1;
  emxArray_real_T *acol;
  emxArray_real_T *b_CA;
  emxArray_real_T *b_acol;
  emxArray_int32_T *r0;
  int p;
  int first[10];
  int last[10];
  int b_abd_size[2];
  emxInit_real_T(&c, 2);
  i0 = c->size[0] * c->size[1];
  c->size[0] = 1;
  c->size[1] = 0;
  emxEnsureCapacity_real_T(c, i0);
  for (i0 = 0; i0 < 12; i0++) {
    l[i0] = 0;
  }

  xv_size[0] = 1;
  xv_size[1] = abd_size[1];
  loop_ub = abd_size[1];
  if (0 <= loop_ub - 1) {
    memcpy(&xv_data[0], &abd_data[0], (unsigned int)(loop_ub * (int)sizeof
            (double)));
  }

  if (abd_size[1] != 0) {
    l[11] = (short)abd_size[1];
    emxInit_real_T(&d, 2);
    for (i = 0; i < 10; i++) {
      dwt(xv_data, xv_size, b_xv_data, b_xv_size, d_data, d_size);
      xv_size[0] = 1;
      xv_size[1] = b_xv_size[1];
      loop_ub = b_xv_size[0] * b_xv_size[1];
      if (0 <= loop_ub - 1) {
        memcpy(&xv_data[0], &b_xv_data[0], (unsigned int)(loop_ub * (int)sizeof
                (double)));
      }

      i0 = d->size[0] * d->size[1];
      d->size[0] = 1;
      d->size[1] = d_size[1] + c->size[1];
      emxEnsureCapacity_real_T(d, i0);
      loop_ub = d_size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        d->data[d->size[0] * i0] = d_data[d_size[0] * i0];
      }

      loop_ub = c->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        d->data[d->size[0] * (i0 + d_size[1])] = c->data[c->size[0] * i0];
      }

      i0 = c->size[0] * c->size[1];
      c->size[0] = 1;
      c->size[1] = d->size[1];
      emxEnsureCapacity_real_T(c, i0);
      loop_ub = d->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        c->data[c->size[0] * i0] = d->data[d->size[0] * i0];
      }

      l[10 - i] = (short)d_size[1];
    }

    i0 = d->size[0] * d->size[1];
    d->size[0] = 1;
    d->size[1] = xv_size[1] + c->size[1];
    emxEnsureCapacity_real_T(d, i0);
    loop_ub = xv_size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d->data[d->size[0] * i0] = xv_data[i0];
    }

    loop_ub = c->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      d->data[d->size[0] * (i0 + xv_size[1])] = c->data[c->size[0] * i0];
    }

    i0 = c->size[0] * c->size[1];
    c->size[0] = 1;
    c->size[1] = d->size[1];
    emxEnsureCapacity_real_T(c, i0);
    loop_ub = d->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      c->data[c->size[0] * i0] = d->data[d->size[0] * i0];
    }

    emxFree_real_T(&d);
    l[0] = (short)xv_size[1];
  }

  if (1 > l[0]) {
    i0 = 0;
  } else {
    i0 = l[0];
  }

  emxInit_real_T(&CA, 2);
  i = (i0 + c->size[1]) - l[0];
  i1 = CA->size[0] * CA->size[1];
  CA->size[0] = 1;
  CA->size[1] = i;
  emxEnsureCapacity_real_T(CA, i1);
  for (i1 = 0; i1 < i; i1++) {
    CA->data[i1] = 0.0;
  }

  for (i = 0; i + 1 <= i0; i++) {
    CA->data[CA->size[0] * i] = c->data[i];
  }

  emxFree_real_T(&c);
  emxInit_real_T1(&acol, 1);
  i0 = acol->size[0];
  acol->size[0] = l[0];
  emxEnsureCapacity_real_T1(acol, i0);
  for (i = 0; i < l[0]; i++) {
    acol->data[i] = CA->data[i];
  }

  emxInit_real_T1(&b_CA, 1);
  emxInit_real_T1(&b_acol, 1);
  emxInit_int32_T(&r0, 1);
  for (p = 9; p >= 0; p--) {
    for (i = 0; i < 10; i++) {
      first[i] = 0;
      last[i] = 0;
    }

    first[9] = l[0] + 1;
    last[9] = l[0] + l[1];
    for (i = 8; i >= 0; i--) {
      first[i] = first[i + 1] + l[9 - i];
      last[i] = (first[i] + l[10 - i]) - 1;
    }

    if (first[p] > last[p]) {
      i0 = 1;
      i1 = 0;
    } else {
      i0 = first[p];
      i1 = last[p];
    }

    i = r0->size[0];
    r0->size[0] = (i1 - i0) + 1;
    emxEnsureCapacity_int32_T(r0, i);
    loop_ub = i1 - i0;
    for (i = 0; i <= loop_ub; i++) {
      r0->data[i] = i0 + i;
    }

    i = b_CA->size[0];
    b_CA->size[0] = (i1 - i0) + 1;
    emxEnsureCapacity_real_T1(b_CA, i);
    loop_ub = i1 - i0;
    for (i0 = 0; i0 <= loop_ub; i0++) {
      b_CA->data[i0] = CA->data[r0->data[i0] - 1];
    }

    i0 = b_acol->size[0];
    b_acol->size[0] = acol->size[0];
    emxEnsureCapacity_real_T1(b_acol, i0);
    loop_ub = acol->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_acol->data[i0] = acol->data[i0];
    }

    idwt(b_acol, b_CA, (double)l[11 - p], acol);
  }

  emxFree_int32_T(&r0);
  emxFree_real_T(&b_acol);
  emxFree_real_T(&b_CA);
  emxFree_real_T(&CA);

  //  figure
  //  plot(x,a)
  b_abd_size[0] = 1;
  b_abd_size[1] = abd_size[1];
  loop_ub = abd_size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    xv_data[i0] = abd_data[abd_size[0] * i0] - acol->data[i0];
  }

  emxFree_real_T(&acol);
  wden(xv_data, b_abd_size, abd_den);

  //  figure
  //  plot(x,abd_den)
}

//
// File trailer for preprocessing.cpp
//
// [EOF]
//
