//
// File: idwt.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//
#ifndef IDWT_H
#define IDWT_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "preprocessing_types.h"

// Function Declarations
extern void idwt(const emxArray_real_T *a, const emxArray_real_T *d, double
                 varargin_3, emxArray_real_T *x);

#endif

//
// File trailer for idwt.h
//
// [EOF]
//
