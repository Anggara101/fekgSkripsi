//
// File: wextend.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//

// Include Files
#include "rt_nonfinite.h"
#include "preprocessing.h"
#include "wextend.h"

// Function Declarations
static void HP_SymExt(const double x_data[], const int x_size[2], double y_data[],
                      int y_size[2]);
static int div_s32(int numerator, int denominator);
static void getSymIndices(int lx, int I_data[], int I_size[2]);

// Function Definitions

//
// Arguments    : const double x_data[]
//                const int x_size[2]
//                double y_data[]
//                int y_size[2]
// Return Type  : void
//
static void HP_SymExt(const double x_data[], const int x_size[2], double y_data[],
                      int y_size[2])
{
  int J_data[5014];
  int J_size[2];
  int loop_ub;
  int i3;
  getSymIndices(x_size[1], J_data, J_size);
  y_size[0] = 1;
  y_size[1] = J_size[1];
  loop_ub = J_size[1];
  for (i3 = 0; i3 < loop_ub; i3++) {
    y_data[i3] = x_data[x_size[0] * (J_data[J_size[0] * i3] - 1)];
  }
}

//
// Arguments    : int numerator
//                int denominator
// Return Type  : int
//
static int div_s32(int numerator, int denominator)
{
  int quotient;
  unsigned int absNumerator;
  unsigned int absDenominator;
  boolean_T quotientNeedsNegation;
  if (denominator == 0) {
    if (numerator >= 0) {
      quotient = MAX_int32_T;
    } else {
      quotient = MIN_int32_T;
    }
  } else {
    if (numerator < 0) {
      absNumerator = ~(unsigned int)numerator + 1U;
    } else {
      absNumerator = (unsigned int)numerator;
    }

    if (denominator < 0) {
      absDenominator = ~(unsigned int)denominator + 1U;
    } else {
      absDenominator = (unsigned int)denominator;
    }

    quotientNeedsNegation = ((numerator < 0) != (denominator < 0));
    absNumerator /= absDenominator;
    if (quotientNeedsNegation) {
      quotient = -(int)absNumerator;
    } else {
      quotient = (int)absNumerator;
    }
  }

  return quotient;
}

//
// Arguments    : int lx
//                int I_data[]
//                int I_size[2]
// Return Type  : void
//
static void getSymIndices(int lx, int I_data[], int I_size[2])
{
  int lx2;
  int loop_ub;
  int ik;
  lx2 = lx << 1;
  I_size[0] = 1;
  I_size[1] = 14 + lx;
  loop_ub = 14 + lx;
  if (0 <= loop_ub - 1) {
    memset(&I_data[0], 0, (unsigned int)(loop_ub * (int)sizeof(int)));
  }

  if (lx < 7) {
    for (loop_ub = 1; loop_ub <= 7 - lx; loop_ub++) {
      if (lx2 == 0) {
        ik = 1;
      } else {
        ik = 8 - (loop_ub + lx2 * div_s32(7 - loop_ub, lx2));
      }

      if (ik > lx) {
        ik = (lx2 - ik) + 1;
      }

      I_data[loop_ub - 1] = ik;
    }

    for (loop_ub = 8 - lx; loop_ub < 8; loop_ub++) {
      I_data[loop_ub - 1] = 8 - loop_ub;
    }
  } else {
    for (loop_ub = 0; loop_ub < 7; loop_ub++) {
      I_data[loop_ub] = 7 - loop_ub;
    }
  }

  for (loop_ub = 1; loop_ub <= lx; loop_ub++) {
    I_data[6 + loop_ub] = loop_ub;
  }

  if (lx < 7) {
    for (loop_ub = 1; loop_ub <= lx; loop_ub++) {
      I_data[(lx + loop_ub) + 6] = (lx - loop_ub) + 1;
    }

    for (loop_ub = lx + 1; loop_ub < 8; loop_ub++) {
      ik = loop_ub - lx;
      if (ik > lx) {
        if (lx2 == 0) {
          ik = 1;
        } else {
          ik -= lx2 * div_s32(ik - 1, lx2);
        }

        if (ik > lx) {
          ik = (lx2 - ik) + 1;
        }
      }

      I_data[(lx + loop_ub) + 6] = ik;
    }
  } else {
    for (loop_ub = 0; loop_ub < 7; loop_ub++) {
      I_data[(lx + loop_ub) + 7] = lx - loop_ub;
    }
  }
}

//
// Arguments    : const double x_data[]
//                const int x_size[2]
//                double y_data[]
//                int y_size[2]
// Return Type  : void
//
void wextend(const double x_data[], const int x_size[2], double y_data[], int
             y_size[2])
{
  if (x_size[1] == 0) {
    y_size[0] = 1;
    y_size[1] = 14;
    memset(&y_data[0], 0, 14U * sizeof(double));
  } else {
    HP_SymExt(x_data, x_size, y_data, y_size);
  }
}

//
// File trailer for wextend.cpp
//
// [EOF]
//
