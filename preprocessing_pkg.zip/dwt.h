//
// File: dwt.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//
#ifndef DWT_H
#define DWT_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "preprocessing_types.h"

// Function Declarations
extern void dwt(const double x_data[], const int x_size[2], double a_data[], int
                a_size[2], double d_data[], int d_size[2]);

#endif

//
// File trailer for dwt.h
//
// [EOF]
//
