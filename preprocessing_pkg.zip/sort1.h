//
// File: sort1.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//
#ifndef SORT1_H
#define SORT1_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "preprocessing_types.h"

// Function Declarations
extern void sort(emxArray_real_T *x);

#endif

//
// File trailer for sort1.h
//
// [EOF]
//
