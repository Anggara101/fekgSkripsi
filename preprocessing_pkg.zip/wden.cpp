//
// File: wden.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//

// Include Files
#include "rt_nonfinite.h"
#include "preprocessing.h"
#include "wden.h"
#include "preprocessing_emxutil.h"
#include "idwt.h"
#include "thselect.h"
#include "wnoisest.h"
#include "dwt.h"

// Function Definitions

//
// Arguments    : const double in1_data[]
//                const int in1_size[2]
//                emxArray_real_T *xd
// Return Type  : void
//
void wden(const double in1_data[], const int in1_size[2], emxArray_real_T *xd)
{
  emxArray_real_T *c;
  int i6;
  int xv_size[2];
  double l[7];
  int n;
  static double xv_data[5000];
  emxArray_real_T *d;
  double s[5];
  int k;
  double b_xv_data[2503];
  int b_xv_size[2];
  double d_data[2503];
  int d_size[2];
  double thrs[5];
  int first[5];
  int tmp;
  emxArray_real_T *cxd;
  int last[5];
  emxArray_int32_T *flk;
  emxArray_real_T *x;
  emxArray_real_T *acol;
  int b_k;
  emxArray_real_T *b_cxd;
  double thr;
  emxArray_real_T *b_acol;
  emxArray_int32_T *r3;
  boolean_T exitg1;
  emxInit_real_T(&c, 2);
  i6 = c->size[0] * c->size[1];
  c->size[0] = 1;
  c->size[1] = 0;
  emxEnsureCapacity_real_T(c, i6);
  for (i6 = 0; i6 < 7; i6++) {
    l[i6] = 0.0;
  }

  xv_size[0] = 1;
  xv_size[1] = in1_size[1];
  n = in1_size[1];
  if (0 <= n - 1) {
    memcpy(&xv_data[0], &in1_data[0], (unsigned int)(n * (int)sizeof(double)));
  }

  emxInit_real_T(&d, 2);
  if (in1_size[1] != 0) {
    l[6] = in1_size[1];
    for (k = 0; k < 5; k++) {
      dwt(xv_data, xv_size, b_xv_data, b_xv_size, d_data, d_size);
      xv_size[0] = 1;
      xv_size[1] = b_xv_size[1];
      n = b_xv_size[0] * b_xv_size[1];
      if (0 <= n - 1) {
        memcpy(&xv_data[0], &b_xv_data[0], (unsigned int)(n * (int)sizeof(double)));
      }

      i6 = d->size[0] * d->size[1];
      d->size[0] = 1;
      d->size[1] = d_size[1] + c->size[1];
      emxEnsureCapacity_real_T(d, i6);
      n = d_size[1];
      for (i6 = 0; i6 < n; i6++) {
        d->data[d->size[0] * i6] = d_data[d_size[0] * i6];
      }

      n = c->size[1];
      for (i6 = 0; i6 < n; i6++) {
        d->data[d->size[0] * (i6 + d_size[1])] = c->data[c->size[0] * i6];
      }

      i6 = c->size[0] * c->size[1];
      c->size[0] = 1;
      c->size[1] = d->size[1];
      emxEnsureCapacity_real_T(c, i6);
      n = d->size[1];
      for (i6 = 0; i6 < n; i6++) {
        c->data[c->size[0] * i6] = d->data[d->size[0] * i6];
      }

      l[5 - k] = d_size[1];
    }

    i6 = d->size[0] * d->size[1];
    d->size[0] = 1;
    d->size[1] = xv_size[1] + c->size[1];
    emxEnsureCapacity_real_T(d, i6);
    n = xv_size[1];
    for (i6 = 0; i6 < n; i6++) {
      d->data[d->size[0] * i6] = xv_data[i6];
    }

    n = c->size[1];
    for (i6 = 0; i6 < n; i6++) {
      d->data[d->size[0] * (i6 + xv_size[1])] = c->data[c->size[0] * i6];
    }

    i6 = c->size[0] * c->size[1];
    c->size[0] = 1;
    c->size[1] = d->size[1];
    emxEnsureCapacity_real_T(c, i6);
    n = d->size[1];
    for (i6 = 0; i6 < n; i6++) {
      c->data[c->size[0] * i6] = d->data[d->size[0] * i6];
    }

    l[0] = xv_size[1];
  }

  wnoisest(c, l, s);
  for (i6 = 0; i6 < 5; i6++) {
    thrs[i6] = (short)l[i6];
  }

  for (k = 0; k < 4; k++) {
    thrs[k + 1] += thrs[k];
  }

  for (i6 = 0; i6 < 5; i6++) {
    first[i6] = (int)thrs[i6] + 1;
  }

  for (k = 0; k < 2; k++) {
    tmp = first[k];
    first[k] = first[4 - k];
    first[4 - k] = tmp;
  }

  for (i6 = 0; i6 < 5; i6++) {
    last[i6] = ((short)l[5 - i6] + first[i6]) - 1;
  }

  emxInit_real_T(&cxd, 2);
  i6 = cxd->size[0] * cxd->size[1];
  cxd->size[0] = 1;
  cxd->size[1] = c->size[1];
  emxEnsureCapacity_real_T(cxd, i6);
  n = c->size[0] * c->size[1];
  for (i6 = 0; i6 < n; i6++) {
    cxd->data[i6] = c->data[i6];
  }

  emxInit_int32_T1(&flk, 2);
  emxInit_real_T(&x, 2);
  for (k = 0; k < 5; k++) {
    if (last[k] < first[k]) {
      n = 0;
    } else {
      n = (last[k] - first[k]) + 1;
    }

    i6 = flk->size[0] * flk->size[1];
    flk->size[0] = 1;
    flk->size[1] = n;
    emxEnsureCapacity_int32_T1(flk, i6);
    if (n > 0) {
      flk->data[0] = first[k];
      tmp = first[k];
      for (b_k = 2; b_k <= n; b_k++) {
        tmp++;
        flk->data[b_k - 1] = tmp;
      }
    }

    tmp = 1;
    n = flk->size[1];
    thr = c->data[flk->data[0] - 1];
    if (flk->size[1] > 1) {
      if (rtIsNaN(thr)) {
        b_k = 2;
        exitg1 = false;
        while ((!exitg1) && (b_k <= n)) {
          tmp = b_k;
          if (!rtIsNaN(c->data[flk->data[flk->size[0] * (b_k - 1)] - 1])) {
            thr = c->data[flk->data[flk->size[0] * (b_k - 1)] - 1];
            exitg1 = true;
          } else {
            b_k++;
          }
        }
      }

      if (tmp < flk->size[1]) {
        while (tmp + 1 <= n) {
          if (c->data[flk->data[flk->size[0] * tmp] - 1] > thr) {
            thr = c->data[flk->data[flk->size[0] * tmp] - 1];
          }

          tmp++;
        }
      }
    }

    if (s[k] < 1.4901161193847656E-8 * thr) {
      thr = 0.0;
    } else {
      i6 = d->size[0] * d->size[1];
      d->size[0] = 1;
      d->size[1] = flk->size[1];
      emxEnsureCapacity_real_T(d, i6);
      n = flk->size[0] * flk->size[1];
      for (i6 = 0; i6 < n; i6++) {
        d->data[i6] = c->data[flk->data[i6] - 1] / s[k];
      }

      thr = thselect(d);
    }

    thrs[k] = thr * s[k];
    i6 = x->size[0] * x->size[1];
    x->size[0] = 1;
    x->size[1] = flk->size[1];
    emxEnsureCapacity_real_T(x, i6);
    n = flk->size[0] * flk->size[1];
    for (i6 = 0; i6 < n; i6++) {
      x->data[i6] = c->data[flk->data[i6] - 1];
    }

    i6 = flk->size[1];
    for (b_k = 0; b_k < i6; b_k++) {
      x->data[b_k] *= (double)(std::abs(x->data[b_k]) > thrs[k]);
    }

    n = x->size[0] * x->size[1];
    for (i6 = 0; i6 < n; i6++) {
      cxd->data[flk->data[i6] - 1] = x->data[i6];
    }
  }

  emxFree_real_T(&d);
  emxFree_real_T(&x);
  emxFree_real_T(&c);
  emxFree_int32_T(&flk);
  emxInit_real_T1(&acol, 1);
  i6 = acol->size[0];
  acol->size[0] = (short)l[0];
  emxEnsureCapacity_real_T1(acol, i6);
  for (k = 0; k < (short)l[0]; k++) {
    acol->data[k] = cxd->data[k];
  }

  emxInit_real_T1(&b_cxd, 1);
  emxInit_real_T1(&b_acol, 1);
  emxInit_int32_T(&r3, 1);
  for (k = 4; k >= 0; k--) {
    for (i6 = 0; i6 < 5; i6++) {
      first[i6] = 0;
      last[i6] = 0;
    }

    first[4] = (short)l[0] + 1;
    last[4] = (short)l[0] + (short)l[1];
    for (tmp = 3; tmp >= 0; tmp--) {
      first[tmp] = first[tmp + 1] + (short)l[4 - tmp];
      last[tmp] = (first[tmp] + (short)l[5 - tmp]) - 1;
    }

    if (first[k] > last[k]) {
      i6 = 1;
      tmp = 0;
    } else {
      i6 = first[k];
      tmp = last[k];
    }

    b_k = r3->size[0];
    r3->size[0] = (tmp - i6) + 1;
    emxEnsureCapacity_int32_T(r3, b_k);
    n = tmp - i6;
    for (b_k = 0; b_k <= n; b_k++) {
      r3->data[b_k] = i6 + b_k;
    }

    b_k = b_cxd->size[0];
    b_cxd->size[0] = (tmp - i6) + 1;
    emxEnsureCapacity_real_T1(b_cxd, b_k);
    n = tmp - i6;
    for (i6 = 0; i6 <= n; i6++) {
      b_cxd->data[i6] = cxd->data[r3->data[i6] - 1];
    }

    i6 = b_acol->size[0];
    b_acol->size[0] = acol->size[0];
    emxEnsureCapacity_real_T1(b_acol, i6);
    n = acol->size[0];
    for (i6 = 0; i6 < n; i6++) {
      b_acol->data[i6] = acol->data[i6];
    }

    idwt(b_acol, b_cxd, (double)(short)l[6 - k], acol);
  }

  emxFree_int32_T(&r3);
  emxFree_real_T(&b_acol);
  emxFree_real_T(&b_cxd);
  emxFree_real_T(&cxd);
  i6 = xd->size[0] * xd->size[1];
  xd->size[0] = 1;
  xd->size[1] = acol->size[0];
  emxEnsureCapacity_real_T(xd, i6);
  n = acol->size[0];
  for (i6 = 0; i6 < n; i6++) {
    xd->data[xd->size[0] * i6] = acol->data[i6];
  }

  emxFree_real_T(&acol);
}

//
// File trailer for wden.cpp
//
// [EOF]
//
