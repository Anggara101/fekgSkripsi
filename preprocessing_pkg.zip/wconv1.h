//
// File: wconv1.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//
#ifndef WCONV1_H
#define WCONV1_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "preprocessing_types.h"

// Function Declarations
extern void b_wconv1(const double x_data[], const int x_size[2], double y_data[],
                     int y_size[2]);
extern void wconv1(const double x_data[], const int x_size[2], double y_data[],
                   int y_size[2]);

#endif

//
// File trailer for wconv1.h
//
// [EOF]
//
