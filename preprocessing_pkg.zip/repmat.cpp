//
// File: repmat.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//

// Include Files
#include "rt_nonfinite.h"
#include "preprocessing.h"
#include "repmat.h"
#include "preprocessing_emxutil.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *a
//                emxArray_real_T *b
// Return Type  : void
//
void repmat(const emxArray_real_T *a, emxArray_real_T *b)
{
  int outsize_idx_0;
  int i7;
  outsize_idx_0 = a->size[0];
  i7 = b->size[0];
  b->size[0] = outsize_idx_0;
  emxEnsureCapacity_real_T1(b, i7);
  if ((!(a->size[0] == 0)) && (!(outsize_idx_0 == 0))) {
    for (outsize_idx_0 = 0; outsize_idx_0 + 1 <= a->size[0]; outsize_idx_0++) {
      b->data[outsize_idx_0] = a->data[outsize_idx_0];
    }
  }
}

//
// File trailer for repmat.cpp
//
// [EOF]
//
