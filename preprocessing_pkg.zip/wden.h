//
// File: wden.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//
#ifndef WDEN_H
#define WDEN_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "preprocessing_types.h"

// Function Declarations
extern void wden(const double in1_data[], const int in1_size[2], emxArray_real_T
                 *xd);

#endif

//
// File trailer for wden.h
//
// [EOF]
//
