//
// File: preprocessing.h
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//
#ifndef PREPROCESSING_H
#define PREPROCESSING_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "preprocessing_types.h"

// Function Declarations
extern void preprocessing(const double abd_data[], const int abd_size[2],
  emxArray_real_T *abd_den);

#endif

//
// File trailer for preprocessing.h
//
// [EOF]
//
