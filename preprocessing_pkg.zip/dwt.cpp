//
// File: dwt.cpp
//
// MATLAB Coder version            : 3.4
// C/C++ source code generated on  : 12-Jan-2022 20:41:51
//

// Include Files
#include "rt_nonfinite.h"
#include "preprocessing.h"
#include "dwt.h"
#include "wconv1.h"
#include "wextend.h"

// Function Definitions

//
// Arguments    : const double x_data[]
//                const int x_size[2]
//                double a_data[]
//                int a_size[2]
//                double d_data[]
//                int d_size[2]
// Return Type  : void
//
void dwt(const double x_data[], const int x_size[2], double a_data[], int
         a_size[2], double d_data[], int d_size[2])
{
  static double y_data[5014];
  int y_size[2];
  static double z_data[5007];
  int z_size[2];
  int loop_ub;
  int i2;
  wextend(x_data, x_size, y_data, y_size);
  wconv1(y_data, y_size, z_data, z_size);
  a_size[0] = 1;
  a_size[1] = ((x_size[1] + 5) >> 1) + 1;
  loop_ub = (x_size[1] + 5) >> 1;
  for (i2 = 0; i2 <= loop_ub; i2++) {
    a_data[i2] = z_data[1 + (i2 << 1)];
  }

  b_wconv1(y_data, y_size, z_data, z_size);
  d_size[0] = 1;
  d_size[1] = ((x_size[1] + 5) >> 1) + 1;
  loop_ub = (x_size[1] + 5) >> 1;
  for (i2 = 0; i2 <= loop_ub; i2++) {
    d_data[i2] = z_data[1 + (i2 << 1)];
  }
}

//
// File trailer for dwt.cpp
//
// [EOF]
//
